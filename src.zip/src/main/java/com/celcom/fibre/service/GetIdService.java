package com.celcom.fibre.service;

import java.rmi.server.ServerNotActiveException;

import javax.naming.NotContextException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.celcom.fibre.model.outbound.activity.ActivityDetailsRetrieveRequest;
import com.celcom.fibre.model.outbound.activity.ActivityDetailsRetrieveResponseDTO;
import com.celcom.fibre.model.outbound.customer.CustomerRetrieveResponse;
import com.celcom.fibre.model.inbound.order.OrderListRetrieveRequest;
import com.celcom.fibre.model.inbound.order.OrderListRetrieveRequestModel;
import com.celcom.fibre.model.outbound.order.OrderListRetrieveResponse;
import com.celcom.fibre.model.outbound.customerdetail.InstallerPortalCustomerRetrieveResponseDTO;
//import com.celcom.fibre.model.outbound.orderactivity.Response;
import com.celcom.fibre.model.inbound.activity.ActivityDetailsRetrieveRequestmodel;

import com.celcom.fibre.model.inbound.activity.IGWAuthResponse;
import com.celcom.fibre.model.inbound.customer.CustomerRetrieveRequestModel;
import com.celcom.fibre.model.inbound.customer.CustomerRetrieveRequestNewModel;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

import reactor.core.publisher.Flux;

@Service
public class GetIdService {

	// Auto-wired the web-client
	@Autowired
	private WebClient webClientBuilder;
	
	@Value("${ActivityDetailsRetrieve_URL}")
	private String URI1;
	
	@Value("${CustomerRetrieve_URL}")
	private String URI3;
	
	public ActivityDetailsRetrieveResponseDTO getIdsService(ActivityDetailsRetrieveRequestmodel activityRetrieveRequestmodel , String igwAccessToken) throws NotContextException , ServerNotActiveException{

		String accessToken = igwAccessToken; //acivity.getAccessToken();
       
		try {

	ActivityDetailsRetrieveResponseDTO data = webClientBuilder
				.post()
				.uri(URI1)
			    .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.headers(headers -> headers.setBearerAuth(accessToken))
				.body(BodyInserters.fromValue(activityRetrieveRequestmodel.getActivityDetailsRetrieveRequest()))
			    .retrieve()
				.bodyToMono(ActivityDetailsRetrieveResponseDTO.class).block();
	if(data!=null) {
		return data;
	}
	else {
		throw new NotContextException("not Context exception");
	}
	}
	catch (NotContextException e) {
		throw new NotContextException("not found");
	}
	catch (Exception e) {
		throw new ServerNotActiveException("server not found");
	}
}
			
	public InstallerPortalCustomerRetrieveResponseDTO getcustomerservice(CustomerRetrieveRequestNewModel customer , String igwAccessToken) {
		String accessToken = igwAccessToken; //customer.getAccessToken();
		return webClientBuilder
				 .post()
				 .uri("")
				 .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
				 .contentType(MediaType.APPLICATION_JSON)
				 .accept(MediaType.APPLICATION_JSON)
				 .headers(headers -> headers.setBearerAuth(accessToken))
				 .body(BodyInserters.fromValue(customer.getInstallerPortalCustomerRetrieveRequestDTO()))
				 .retrieve()
				 .bodyToMono(InstallerPortalCustomerRetrieveResponseDTO.class).block();
		
	}
}
