package com.celcom.fibre.service;

import java.rmi.server.ServerNotActiveException;

import javax.naming.NotContextException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.celcom.fibre.model.outbound.ordersearch.CustomOrderSearchRequestWithCustomerId;
import com.celcom.fibre.model.outbound.ordersearch.CustomOrderSearchRequestWithOrderNumber;
import com.celcom.fibre.model.outbound.ordersearch.CustomOrderSearchRequestWithOrderStatus;
import com.celcom.fibre.model.outbound.ordersearch.CustomOrderSearchRequestWithServiceId;
import com.celcom.fibre.model.outbound.ordersearch.CustomOrderSearchResponseDTO;

public class OrderListService {
	
	@Value("${TrackOrderByOrderIDUrl}")
	private String trackOrderIdURL;
	
	@Value("${TrackOrderByCustomerIDUrl}")
	private String trackCustomerIdURL;
	
	@Value("${TrackOrderByServiceIDUrl}")
	private String trackServiceIDURL;
	
	@Value("${TrackOrderByOrderStatusUrl}")
	private String trackOrderStatusURL;
	
	
	@Autowired
	private WebClient webClientBuilder;
	
	public CustomOrderSearchResponseDTO getOrderDetailByOrderIdService(CustomOrderSearchRequestWithOrderNumber trackOrderSearchInput, String igwAccessToken) throws NotContextException , ServerNotActiveException {
		    
	    try {
			return webClientBuilder
					 .post()
					 .uri(trackOrderIdURL)
					 .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
					 .header("accessToken",igwAccessToken)
					 .body(BodyInserters.fromValue(trackOrderSearchInput))
					 .retrieve()
					 .bodyToMono(CustomOrderSearchResponseDTO.class).block();
			
		}
		catch (Exception e) {
			throw new ServerNotActiveException("server not found");
		}
	}
	
	
	public CustomOrderSearchResponseDTO getOrderDetailByCustomerIdService(CustomOrderSearchRequestWithCustomerId trackOrderSearchInput, String igwAccessToken) throws NotContextException , ServerNotActiveException {
	    
	    try {
			return webClientBuilder
					 .post()
					 .uri(trackCustomerIdURL)
					 .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
					 .header("accessToken",igwAccessToken)
					 .body(BodyInserters.fromValue(trackOrderSearchInput))
					 .retrieve()
					 .bodyToMono(CustomOrderSearchResponseDTO.class).block();
			
		}
		catch (Exception e) {
			throw new ServerNotActiveException("server not found");
		}
	}
	
	public CustomOrderSearchResponseDTO getOrderDetailByOrderStatusService(CustomOrderSearchRequestWithOrderStatus trackOrderSearchInput, String igwAccessToken) throws NotContextException , ServerNotActiveException {
	    
	    try {
			return webClientBuilder
					 .post()
					 .uri(trackOrderStatusURL)
					 .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
					 .header("accessToken",igwAccessToken)
					 .body(BodyInserters.fromValue(trackOrderSearchInput))
					 .retrieve()
					 .bodyToMono(CustomOrderSearchResponseDTO.class).block();
			
		}
		catch (Exception e) {
			throw new ServerNotActiveException("server not found");
		}
	}
	
	public CustomOrderSearchResponseDTO getOrderDetailByServiceIDService(CustomOrderSearchRequestWithServiceId trackOrderSearchInput, String igwAccessToken) throws NotContextException , ServerNotActiveException {
	    
	    try {
			return webClientBuilder
					 .post()
					 .uri(trackServiceIDURL)
					 .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
					 .header("accessToken",igwAccessToken)
					 .body(BodyInserters.fromValue(trackOrderSearchInput))
					 .retrieve()
					 .bodyToMono(CustomOrderSearchResponseDTO.class).block();
			
		}
		catch (Exception e) {
			throw new ServerNotActiveException("server not found");
		}
	}

}
