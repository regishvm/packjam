package com.celcom.fibre.service;

import java.io.File;
import java.rmi.server.ServerNotActiveException;

import javax.naming.NotContextException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.celcom.fibre.model.outbound.workorder.GetWorkItemDetailsRequestDTO;
import com.celcom.fibre.model.outbound.workorder.GetWorkItemDetailsResponseDTO;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class WorkOrderDetailService {

	// Auto-wired the web-client
	@Autowired
	private WebClient webClientBuilder;

	@Value("${ActivityDetailsFullRetrieve_URL}")
	private String workItemDetailsFullURL;

	public GetWorkItemDetailsResponseDTO getWorkItemDetailsByIdService(
			GetWorkItemDetailsRequestDTO wotkItemDetailInputRequest, String igwAccessToken)
			throws NotContextException, ServerNotActiveException {

		try {

//			GetWorkItemDetailsResponseDTO data = webClientBuilder
//					.post()
//					.uri(workItemDetailsFullURL)
//					.header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
//					.contentType(MediaType.APPLICATION_JSON)
//					.accept(MediaType.APPLICATION_JSON)
//					.headers(headers -> headers.setBearerAuth(igwAccessToken))
//					.body(BodyInserters.fromValue(wotkItemDetailInputRequest))
//					.retrieve()
//					.bodyToMono(GetWorkItemDetailsResponseDTO.class).block();
			
		
			File jsonFilewithMaterialdetails = new File("src/main/resources/getworkitemdetails.json");
			ObjectMapper mapper = new ObjectMapper();
			
			mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
			return mapper.readValue(jsonFilewithMaterialdetails, GetWorkItemDetailsResponseDTO.class);
			
//			if (data != null) {
//				return data;
//			} else {
//				throw new NotContextException("not Context exception");
//			}
//		} catch (NotContextException e) {
//			throw new NotContextException("not found");
		} 
		catch (Exception e) {
			throw new ServerNotActiveException("server not found");
		}
	}

}
