package com.celcom.fibre.service;

import java.rmi.server.ServerNotActiveException;

import javax.naming.NotContextException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.celcom.fibre.model.outbound.customerdetail.InstallerPortalCustomerRetrieveRequestDTO;
import com.celcom.fibre.model.outbound.customerdetail.InstallerPortalCustomerRetrieveResponseDTO;


public class CustomerDetailService {
	
	@Value("${CustomerDetails_URL}")
	private String customerDetailURI;
	
	@Autowired
	private WebClient webClientBuilder;
	
	public InstallerPortalCustomerRetrieveResponseDTO getCustomerInformationService(InstallerPortalCustomerRetrieveRequestDTO customerDetailInput, String igwAccessToken) throws NotContextException , ServerNotActiveException {
	    
	    try {

			return webClientBuilder
					 .post()
					 .uri(customerDetailURI)
					 .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
					 .header("accessToken",igwAccessToken)
					 .body(BodyInserters.fromValue(customerDetailInput))
					 .retrieve()
					 .bodyToMono(InstallerPortalCustomerRetrieveResponseDTO.class).block();
			
		}
		catch (Exception e) {
			throw new ServerNotActiveException("server not found");
		}
	}

}
