package com.celcom.fibre.service;

import java.rmi.server.ServerNotActiveException;
import javax.naming.NotContextException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.beans.factory.annotation.Value;

import com.celcom.fibre.model.outbound.itemdetail.FindItemDetailsByOrderIdRequestDTO;
import com.celcom.fibre.model.outbound.itemdetail.FindItemDetailsByOrderIdResponseDTO;
import com.celcom.fibre.model.outbound.itemdetail.OrderIdDTO;

@Service
public class WorkOrderByOrderIdService {
	
	@Value("${ActivityDetailsByOrderId}")
	private String getWOByOrderIdURL;
	
	@Autowired
	private WebClient webClientBuilder;
	
	
	public FindItemDetailsByOrderIdResponseDTO getWorkOrdersByOrderId(String igwAccessToken , String orderID) throws NotContextException , ServerNotActiveException {
	    
	    try {
	    	FindItemDetailsByOrderIdRequestDTO workOrdersByOrderIdInput =  new FindItemDetailsByOrderIdRequestDTO();
	    	
	    	OrderIdDTO inputOrderId =  new OrderIdDTO();
	    	inputOrderId.setOrderID(orderID);
	    	workOrdersByOrderIdInput.setLevelOfInformation("ALL");
	    	
	    	
			return webClientBuilder
					 .post()
					 .uri(getWOByOrderIdURL)
					 .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
					 .header("accessToken",igwAccessToken)
					 .body(BodyInserters.fromValue(workOrdersByOrderIdInput))
					 .retrieve()
					 .bodyToMono(FindItemDetailsByOrderIdResponseDTO.class).block();
			
		}
		catch (Exception e) {
			throw new ServerNotActiveException("server not found");
		}
	}
}
