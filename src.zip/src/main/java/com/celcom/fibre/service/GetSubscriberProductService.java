package com.celcom.fibre.service;

import java.rmi.server.ServerNotActiveException;

import javax.naming.NotContextException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.celcom.fibre.model.outbound.order.OrderListRetrieveResponse;
import com.celcom.fibre.model.outbound.subscriberproducts.SubscriberProductsResponse;

@Service
public class GetSubscriberProductService {
	
	@Value("${SubscriberProductForActivityURL}")
	private String getProductDetailForSubscriberUrl;
	
	@Autowired
	private WebClient webClientBuilder;
	
	public SubscriberProductsResponse getSubscriberProductService( String subscriberId, String accessToken) throws NotContextException , ServerNotActiveException {
		String productBySubscriberIdUrl = getProductDetailForSubscriberUrl+subscriberId;
	    
	    try {
	    	SubscriberProductsResponse data = webClientBuilder
				.get()
				.uri(productBySubscriberIdUrl)
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
				.accept(MediaType.APPLICATION_JSON)
				.headers(headers -> headers.setBearerAuth(accessToken))
				.retrieve()
				.bodyToMono(SubscriberProductsResponse.class)
				.block();
		if(data!=null) {
			return data;
		}
		else {
			throw new NotContextException("No context exception");
		}
		}
		catch (NotContextException e) {
			throw new NotContextException("Not found");
		}
		catch (Exception e) {
			throw new ServerNotActiveException("Server not found");
		}
	}

}
