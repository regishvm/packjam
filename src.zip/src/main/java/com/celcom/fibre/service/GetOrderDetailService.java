package com.celcom.fibre.service;

import java.rmi.server.ServerNotActiveException;
import javax.naming.NotContextException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.beans.factory.annotation.Value;
import com.celcom.fibre.model.outbound.order.OrderListRetrieveResponse;

@Service
public class GetOrderDetailService {
	
	@Value("${OrderDetails_URL}")
	private String orderDetailsURI;
	
	@Autowired
	private WebClient webClientBuilder;
	
	
	public OrderListRetrieveResponse getOrderDetailByOrderIdService(String accessToken , String orderID) throws NotContextException , ServerNotActiveException {

		String uriString = orderDetailsURI+orderID;
	    
	    try {
			OrderListRetrieveResponse data = webClientBuilder
				.get()
				.uri(uriString)
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
				.accept(MediaType.APPLICATION_JSON)
				.headers(headers -> headers.setBearerAuth(accessToken))
				.retrieve()
				.bodyToMono(OrderListRetrieveResponse.class)
				.block();
		if(data!=null) {
			return data;
		}
		else {
			throw new NotContextException("not Context exception");
		}
		}
		catch (NotContextException e) {
			throw new NotContextException("not found");
		}
		catch (Exception e) {
			throw new ServerNotActiveException("server not found");
		}
	}
}
