package com.celcom.fibre.adapter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Service;

import com.celcom.fibre.model.inbound.ordersearch.OrderSearchRequest;
import com.celcom.fibre.model.outbound.ordersearch.CustomOrderSearchRequestWithCustomerId;
import com.celcom.fibre.model.outbound.ordersearch.CustomOrderSearchRequestWithOrderNumber;
import com.celcom.fibre.model.outbound.ordersearch.CustomOrderSearchRequestWithOrderStatus;
import com.celcom.fibre.model.outbound.ordersearch.CustomOrderSearchRequestWithServiceId;

import io.netty.util.internal.StringUtil;

@Service
public class TrackOrderRequestTransformer {
	
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
	
	private static final String TIMEDEAFULTSTART = " 00:00:00";
	private static final String TIMEDEAFULTEND = " 23:59:59";
	private static final String DATEDEFAULTSTART = "2021-01-01 00:00:00";
	
	public CustomOrderSearchRequestWithOrderNumber orderListByOrderIdRequestTransformer(OrderSearchRequest orderIDInput) {
		
		CustomOrderSearchRequestWithOrderNumber orderSearchByOrderIDInput =  new CustomOrderSearchRequestWithOrderNumber();
		
		orderSearchByOrderIDInput.setDealerCode(!StringUtil.isNullOrEmpty(orderIDInput.getDealerCode()) ? orderIDInput.getDealerCode() : null);
		orderSearchByOrderIDInput.setOrderContext(!StringUtil.isNullOrEmpty(orderIDInput.getOrderContext()) ? orderIDInput.getOrderContext() : null);
		if(!StringUtil.isNullOrEmpty(orderIDInput.getOrderNumber())) {
			orderSearchByOrderIDInput.setOrderNumber(orderIDInput.getOrderNumber());
		} 
		
		if (!StringUtil.isNullOrEmpty(orderIDInput.getStartDate()) && !StringUtil.isNullOrEmpty(orderIDInput.getEndDate())){
				
				orderSearchByOrderIDInput.setStartDate(isDateValid(orderIDInput.getStartDate()) ? orderIDInput.getStartDate()+TIMEDEAFULTSTART : DATEDEFAULTSTART);
				orderSearchByOrderIDInput.setEndDate(isDateValid(orderIDInput.getEndDate()) ? orderIDInput.getEndDate()+TIMEDEAFULTEND : dateFormat.format(new Date())+TIMEDEAFULTEND);
		}
		
		return orderSearchByOrderIDInput;
		
	}
	
	public CustomOrderSearchRequestWithCustomerId orderListByCustomerIdRequestTransformer(OrderSearchRequest orderIDInput) {
		
		CustomOrderSearchRequestWithCustomerId orderSearchByCustomerIDInput =  new CustomOrderSearchRequestWithCustomerId();
		
		orderSearchByCustomerIDInput.setDealerCode(!StringUtil.isNullOrEmpty(orderIDInput.getDealerCode()) ? orderIDInput.getDealerCode() : null);
		orderSearchByCustomerIDInput.setOrderContext(!StringUtil.isNullOrEmpty(orderIDInput.getOrderContext()) ? orderIDInput.getOrderContext() : null);
		if(!StringUtil.isNullOrEmpty(orderIDInput.getCustomerId())) {
			orderSearchByCustomerIDInput.setCustomerId(orderIDInput.getCustomerId());
		} 
		
		if (!StringUtil.isNullOrEmpty(orderIDInput.getStartDate()) && !StringUtil.isNullOrEmpty(orderIDInput.getEndDate())){
				
			orderSearchByCustomerIDInput.setStartDate(isDateValid(orderIDInput.getStartDate()) ? orderIDInput.getStartDate()+TIMEDEAFULTSTART : DATEDEFAULTSTART);
			orderSearchByCustomerIDInput.setEndDate(isDateValid(orderIDInput.getEndDate()) ? orderIDInput.getEndDate()+TIMEDEAFULTEND : dateFormat.format(new Date())+TIMEDEAFULTEND);
		}
		
		return orderSearchByCustomerIDInput;
		
	}
	
	public CustomOrderSearchRequestWithOrderStatus orderListByStatusRequestTransformer(OrderSearchRequest orderIDInput) {
		
		CustomOrderSearchRequestWithOrderStatus orderSearchByStatusInput =  new CustomOrderSearchRequestWithOrderStatus();
		
		orderSearchByStatusInput.setDealerCode(!StringUtil.isNullOrEmpty(orderIDInput.getDealerCode()) ? orderIDInput.getDealerCode() : null);
		orderSearchByStatusInput.setOrderContext(!StringUtil.isNullOrEmpty(orderIDInput.getOrderContext()) ? orderIDInput.getOrderContext() : null);
		if(!StringUtil.isNullOrEmpty(orderIDInput.getOrderStatus())) {
			orderSearchByStatusInput.setOrderStatus(orderIDInput.getOrderStatus());
		} 
		
		if (!StringUtil.isNullOrEmpty(orderIDInput.getStartDate()) && !StringUtil.isNullOrEmpty(orderIDInput.getEndDate())){
				
			orderSearchByStatusInput.setStartDate(isDateValid(orderIDInput.getStartDate()) ? orderIDInput.getStartDate()+TIMEDEAFULTSTART : DATEDEFAULTSTART);
			orderSearchByStatusInput.setEndDate(isDateValid(orderIDInput.getEndDate()) ? orderIDInput.getEndDate()+TIMEDEAFULTEND : dateFormat.format(new Date())+TIMEDEAFULTEND);
		}
		
		return orderSearchByStatusInput;
		
	}
	
	
	public CustomOrderSearchRequestWithServiceId orderListByServiceIdRequestTransformer(OrderSearchRequest orderIDInput) {
		
		CustomOrderSearchRequestWithServiceId orderSearchByServiceIdInput =  new CustomOrderSearchRequestWithServiceId();
		
		orderSearchByServiceIdInput.setDealerCode(!StringUtil.isNullOrEmpty(orderIDInput.getDealerCode()) ? orderIDInput.getDealerCode() : null);
		orderSearchByServiceIdInput.setOrderContext(!StringUtil.isNullOrEmpty(orderIDInput.getOrderContext()) ? orderIDInput.getOrderContext() : null);
		
		if(!StringUtil.isNullOrEmpty(orderIDInput.getSrvcAttrKey()) && !StringUtil.isNullOrEmpty(orderIDInput.getSrvcAttrVal())) {
			
				orderSearchByServiceIdInput.setSrvcAttrKey(orderIDInput.getSrvcAttrVal().matches("[0-9]+")	? "MSISDN" : "USER_NAME");	
				orderSearchByServiceIdInput.setSrvcAttrVal(orderIDInput.getSrvcAttrVal());
		} 
		
		if (!StringUtil.isNullOrEmpty(orderIDInput.getStartDate()) && !StringUtil.isNullOrEmpty(orderIDInput.getEndDate())){
				
			orderSearchByServiceIdInput.setStartDate(isDateValid(orderIDInput.getStartDate()) ? orderIDInput.getStartDate()+TIMEDEAFULTSTART : DATEDEFAULTSTART);
			orderSearchByServiceIdInput.setEndDate(isDateValid(orderIDInput.getEndDate()) ? orderIDInput.getEndDate()+TIMEDEAFULTEND : dateFormat.format(new Date())+TIMEDEAFULTEND);
		}
		
		return orderSearchByServiceIdInput;
		
	}
	
	
	public Boolean isDateValid(String dateAsString) {
		
        dateFormat.setLenient(false);
        try {
            dateFormat.parse(dateAsString.trim());
        } catch (ParseException pe) {
            return false;
        }
        return true;
	}
	
	

}
