package com.celcom.fibre.adapter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.celcom.fibre.config.WorkOrderConstants;
import com.celcom.fibre.model.inbound.activity.ActivityDetailRequest;
import com.celcom.fibre.model.inbound.activity.CustomerRequest;
import com.celcom.fibre.model.outbound.customerdetail.InstallerPortalCustomerRetrieveRequestDTO;
import com.celcom.fibre.model.outbound.workorder.GetWorkItemDetailsRequestDTO;

import io.netty.util.internal.StringUtil;

@Service
public class ActivityDetailsRequestTransformer {
	
	
	public GetWorkItemDetailsRequestDTO setActivityDetailsRequestTransformer(ActivityDetailRequest activityDetailInput) {
		
		
		GetWorkItemDetailsRequestDTO workItemDetailsByItemIdRequest = new GetWorkItemDetailsRequestDTO();
		if(!StringUtil.isNullOrEmpty(activityDetailInput.getActivityId())) {
			
				workItemDetailsByItemIdRequest.setItemID(new ArrayList<String>(Arrays
						.asList(activityDetailInput.getActivityId())));
				
				
				
				workItemDetailsByItemIdRequest.setRequestType(WorkOrderConstants.ACTDETAILINPUT_REQUESTTYPE);
				workItemDetailsByItemIdRequest.setInteractionID(WorkOrderConstants.ACTDETAILINPUT_INTERACTIONID+getCurrentDateForUniqueID());
				workItemDetailsByItemIdRequest.setInteractionDate(getCurrrentDateForRequest());
				workItemDetailsByItemIdRequest.setDescription(WorkOrderConstants.ACTDETAILINPUT_DESCRIPTION);
				workItemDetailsByItemIdRequest.setServiceName(WorkOrderConstants.ACTDETAILINPUT_SERVICENAME);
				workItemDetailsByItemIdRequest.setSourceApplicationID(WorkOrderConstants.ACTDETAILINPUT_SOURCE_APPID);
				workItemDetailsByItemIdRequest.setTriggeredBy(activityDetailInput.getUserId());
				workItemDetailsByItemIdRequest.setClientVersion(WorkOrderConstants.ACTDETAILINPUT_CLIENTVERSION);
				workItemDetailsByItemIdRequest.setUuid(removeCharactersFromInput(activityDetailInput.getUserId()));
				workItemDetailsByItemIdRequest.setLang(WorkOrderConstants.ACTDETAILINPUT_LANG);
				workItemDetailsByItemIdRequest.setChannel(WorkOrderConstants.ACTDETAILINPUT_CHANNEL);
				workItemDetailsByItemIdRequest.setOpID(WorkOrderConstants.ACTDETAILINPUT_OPID);		
				workItemDetailsByItemIdRequest.setBuID(WorkOrderConstants.ACTDETAILINPUT_BUID);
		
		}
		
		
		return workItemDetailsByItemIdRequest;
	}
	
	public InstallerPortalCustomerRetrieveRequestDTO setCustomerDetailRequestTransformer(CustomerRequest customerInput) {
		InstallerPortalCustomerRetrieveRequestDTO customerDetailsRequestToIGW =  new InstallerPortalCustomerRetrieveRequestDTO();
		if(!StringUtil.isNullOrEmpty(customerInput.getCustomerId())) {
		
			customerDetailsRequestToIGW.setChannel(WorkOrderConstants.ACTDETAILINPUT_CHANNEL);
			customerDetailsRequestToIGW.setInteractionID(WorkOrderConstants.ACTDETAILINPUT_INTERACTIONID+getCurrentDateForUniqueID());
			customerDetailsRequestToIGW.setInteractionDate(getCurrrentDateForRequest());
			customerDetailsRequestToIGW.setSourceApplicationID(WorkOrderConstants.ACTDETAILINPUT_SOURCE_APPID);
			customerDetailsRequestToIGW.setTriggeredBy(!StringUtil.isNullOrEmpty(customerInput.getUserId()) ? customerInput.getUserId() : "CFMPUSER");
			customerDetailsRequestToIGW.setServiceName(WorkOrderConstants.CUSTDETAILINPUT_SERVICENAME);
			customerDetailsRequestToIGW.setChannel(WorkOrderConstants.ACTDETAILINPUT_CHANNEL);
			customerDetailsRequestToIGW.setUuid(removeCharactersFromInput(customerInput.getUserId()));
			customerDetailsRequestToIGW.setOpID(WorkOrderConstants.ACTDETAILINPUT_OPID);
			customerDetailsRequestToIGW.setBuID(WorkOrderConstants.ACTDETAILINPUT_BUID);
			
		}
		
		return customerDetailsRequestToIGW;
	}
	
	
	
	public String getCurrrentDateForRequest() {
		
		SimpleDateFormat interactionDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZZZ"); 
		GregorianCalendar gconverter = new GregorianCalendar();
		return interactionDateFormat.format(gconverter.getTime());  				
		
	}
	
	public String getCurrentDateForUniqueID() {
	
		SimpleDateFormat interactionIdFormat = new SimpleDateFormat("yyMMddhhmm");
		return interactionIdFormat.format(new Date());
	}
	
	public String removeCharactersFromInput(String valueToConvert) {
		
		String numberRefined = "0";
		numberRefined = valueToConvert.replaceAll("[^\\d-]", "");
		numberRefined = !StringUtil.isNullOrEmpty(numberRefined) ? numberRefined : "0";
		return numberRefined;
	}
	
}
