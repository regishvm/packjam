package com.celcom.fibre.adapter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.celcom.fibre.service.OrderListService;

@Service
public class TrackOrderCommonAdapter {
	
	@Autowired
	private OrderListService trackOrderService;

}
