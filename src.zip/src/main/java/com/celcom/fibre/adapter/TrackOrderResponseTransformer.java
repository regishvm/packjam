package com.celcom.fibre.adapter;

import org.springframework.stereotype.Service;

import com.celcom.fibre.model.inbound.ordersearch.OrderSearchResponse;
import com.celcom.fibre.model.outbound.ordersearch.CustomOrderSearchResponseDTO;

@Service
public class TrackOrderResponseTransformer {

	public OrderSearchResponse orderListCommonResponseTransformer(CustomOrderSearchResponseDTO responseFromIGW) {
		
		OrderSearchResponse trackOrderSearchResponse = new OrderSearchResponse();
		
		
		return trackOrderSearchResponse;
		
	}
}
