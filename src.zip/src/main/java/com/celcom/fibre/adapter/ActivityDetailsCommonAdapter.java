package com.celcom.fibre.adapter;

import java.rmi.server.ServerNotActiveException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.naming.NotContextException;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.celcom.fibre.config.WorkOrderConstants;
import com.celcom.fibre.model.inbound.activity.InstallationAddress;
import com.celcom.fibre.model.inbound.activity.InstallatonDetail;
import com.celcom.fibre.model.inbound.activity.OwnOrderDetails;
import com.celcom.fibre.model.inbound.activity.ProductItem;
import com.celcom.fibre.model.inbound.activity.RelatedWorkOrder;
import com.celcom.fibre.model.inbound.activity.RelatedWorkOrderDetails;
import com.celcom.fibre.model.inbound.activity.SubscriberProducts;
import com.celcom.fibre.model.inbound.customer.CustomerDetailsResponse;
import com.celcom.fibre.model.inbound.order.OrderProductDetail;
import com.celcom.fibre.model.inbound.order.OrderProductItem;
import com.celcom.fibre.model.outbound.itemdetail.DataDTO;
import com.celcom.fibre.model.outbound.itemdetail.FindItemDetailsByOrderIdResponseDTO;
import com.celcom.fibre.model.outbound.order.CommonInformation;
import com.celcom.fibre.model.outbound.order.OrderLine;
import com.celcom.fibre.model.outbound.order.OrderList;
import com.celcom.fibre.model.outbound.order.OrderListRetrieveResponse;
import com.celcom.fibre.model.outbound.order.Subscriber;
import com.celcom.fibre.model.outbound.order.SubscriberProduct;
import com.celcom.fibre.model.outbound.subscriberproducts.Product;
import com.celcom.fibre.model.outbound.subscriberproducts.ProductCharacteristicValue;
import com.celcom.fibre.model.outbound.subscriberproducts.ProductSpecCharacteristicValue;
import com.celcom.fibre.model.outbound.subscriberproducts.SubscriberProductsResponse;
import com.celcom.fibre.model.outbound.workorder.Address;
import com.celcom.fibre.model.outbound.workorder.Attribute;
import com.celcom.fibre.model.outbound.workorder.AttributeList;
import com.celcom.fibre.model.outbound.workorder.ContactMedium;
import com.celcom.fibre.model.outbound.workorder.ItemContactInfo;
import com.celcom.fibre.service.GetOrderDetailService;
import com.celcom.fibre.service.GetSubscriberProductService;
import com.celcom.fibre.service.WorkOrderByOrderIdService;

@Service
public class ActivityDetailsCommonAdapter {
	
	@Autowired
	private WorkOrderByOrderIdService woDetailByOrderIdService;
	
	@Autowired
	private GetSubscriberProductService subscriberProductService;
	
	@Autowired
	private GetOrderDetailService orderDetailsService;
	
	private String serialNoFromResponse = "";
	private String productActiveStartDate = "";
	private String productActiveEndDate = "";
	
	public RelatedWorkOrderDetails getReturnedOrderDetailsByOrderId(String hobsOrderId, String igwAccessToken)
			throws NotContextException, ServerNotActiveException {

		RelatedWorkOrderDetails workOrderDetailsResult = new RelatedWorkOrderDetails();
		List<RelatedWorkOrder> workOrderInfo = new ArrayList<RelatedWorkOrder>();
		try {
			// Calling the service
			FindItemDetailsByOrderIdResponseDTO responseWOByOrderId = woDetailByOrderIdService
					.getWorkOrdersByOrderId(hobsOrderId, igwAccessToken);

			if (responseWOByOrderId != null && responseWOByOrderId.getItems() != null) {

				List<DataDTO> listWorkOrders = responseWOByOrderId.getItems().stream().filter(
						item -> item.getItemSubTypeID().equalsIgnoreCase(WorkOrderConstants.WORKORDER_RETURNED_STATUS))
						.collect(Collectors.toList());

				for (DataDTO returnedWorkOrder : listWorkOrders) {

					RelatedWorkOrder resultWorkOrder = new RelatedWorkOrder(returnedWorkOrder.getItemID(),
							returnedWorkOrder.getItemSubTypeID(), returnedWorkOrder.getItemTypeID(), "",
							returnedWorkOrder.getTargetResolutionDate(), returnedWorkOrder.getPlannedResolutionDate());

					workOrderInfo.add(resultWorkOrder);
				}

				workOrderDetailsResult.setCount(workOrderInfo.size());
				workOrderDetailsResult.setRelatedWorkOrder(workOrderInfo);

			} else {
				workOrderDetailsResult = null;
			}

			return workOrderDetailsResult;

		} catch (NotContextException e) {
			throw new NotContextException(e.getMessage());
		} catch (ServerNotActiveException e) {
			throw new ServerNotActiveException(e.getMessage());
		}
	}

	public InstallationAddress getAddressfromWorkOrderDetail(ItemContactInfo contactInfo) {

		String unitNumber = "";
		String buildingName = "";
		String stretName = "";
		String floorNumber = "";
		String addressType = "";
		String addressCity = "";
		String countryCode = "";
		String pinCode = "";

		String primaryEmail = "";
		String contactNumber = "";
		String dayContactNumber = "";

		List<ContactMedium> contactMedium = contactInfo.getPartyRole().get(0).getContactMedium();

		if (contactMedium != null && contactMedium.size() > 0) {

			List<Address> installAddress = contactMedium.get(0).getAddress();

			if (installAddress != null && installAddress.size() > 0) {

				unitNumber = installAddress.get(0).getAddressLine1();
				buildingName = installAddress.get(0).getAddressLine2();
				floorNumber = installAddress.get(0).getAddressLine3();
				pinCode = installAddress.get(0).getAddressLine4();
				addressCity = installAddress.get(0).getAddressLine5();
				countryCode = installAddress.get(0).getAddressLine6();
				addressType = installAddress.get(0).getAddressType();

			}

			primaryEmail = contactMedium.get(0).getPrimaryEmailID();
			contactNumber = contactMedium.get(0).getTelephoneNumber();
			dayContactNumber = contactMedium.get(0).getDayContactNumber();

		}

		return new InstallationAddress(unitNumber, buildingName, stretName, floorNumber, addressType, addressCity,
				countryCode, pinCode, primaryEmail, contactNumber, dayContactNumber);

	}

	public InstallatonDetail processAdditionalAttributestoFields(AttributeList woAttributes) {

		
		
		if (woAttributes.getAttribute().size() > 0) {
			List<Attribute> listOfAttributes = woAttributes.getAttribute();

//			instalationDetailWo.setInstallerArrivalDate(listOfAttributes.stream()
//					.filter(attribute -> WorkOrderConstants.WORKORDER_INSTALLER_ARRIVAL_DATE_TIME
//							.equalsIgnoreCase(attribute.getName()))
//					.findAny().orElse(null).getValue());
//
//			instalationDetailWo.setLocation(listOfAttributes.stream()
//					.filter(attribute -> WorkOrderConstants.WORKORDER_LOCATION.equalsIgnoreCase(attribute.getName()))
//					.findAny().orElse(null).getValue());
//
//			instalationDetailWo.setStreetName(listOfAttributes.stream()
//					.filter(attribute -> WorkOrderConstants.WORKORDER_STREET_NAME.equalsIgnoreCase(attribute.getName()))
//					.findAny().orElse(null).getValue());
//
//			instalationDetailWo.setLongitude(listOfAttributes.stream()
//					.filter(attribute -> WorkOrderConstants.WORKORDER_LONGITUDE.equalsIgnoreCase(attribute.getName()))
//					.findAny().orElse(null).getValue());
//
//			instalationDetailWo.setLatitude(listOfAttributes.stream()
//					.filter(attribute -> WorkOrderConstants.WORKORDER_LATITUDE.equalsIgnoreCase(attribute.getName()))
//					.findAny().orElse(null).getValue());
//
//			instalationDetailWo.setInstallationCompleteDate(listOfAttributes.stream()
//					.filter(attribute -> WorkOrderConstants.WORKORDER_INSTALLATION_COMPLETE_DATE_TIME
//							.equalsIgnoreCase(attribute.getName()))
//					.findAny().orElse(null).getValue());
//
//			instalationDetailWo.setWorkorderCompleteDate(
//					listOfAttributes.stream().filter(attribute -> WorkOrderConstants.WORKORDER_WORK_ORDER_COMPLETE_DATE
//							.equalsIgnoreCase(attribute.getName())).findAny().orElse(null).getValue());
//
//			instalationDetailWo.setReturnedDate(listOfAttributes.stream().filter(
//					attribute -> WorkOrderConstants.WORKORDER_RETURNED_DATE_TIME.equalsIgnoreCase(attribute.getName()))
//					.findAny().orElse(null).getValue());
//
//			instalationDetailWo.setCableLength(listOfAttributes.stream().filter(
//					attribute -> WorkOrderConstants.WORKORDER_CABLE_LENGTH.equalsIgnoreCase(attribute.getName()))
//					.findAny().orElse(null).getValue());
//
//			instalationDetailWo.setRgwId(listOfAttributes.stream()
//					.filter(attribute -> WorkOrderConstants.WORKORDER_RGW_ID.equalsIgnoreCase(attribute.getName()))
//					.findAny().orElse(null).getValue());
//
//			instalationDetailWo.setBtuId(listOfAttributes.stream()
//					.filter(attribute -> WorkOrderConstants.WORKORDER_BTU_ID.equalsIgnoreCase(attribute.getName()))
//					.findAny().orElse(null).getValue());
//
//			instalationDetailWo.setMesh1Id(listOfAttributes.stream()
//					.filter(attribute -> WorkOrderConstants.WORKORDER_MESH1_ID.equalsIgnoreCase(attribute.getName()))
//					.findAny().orElse(null).getValue());
//
//			instalationDetailWo.setMesh2Id(listOfAttributes.stream()
//					.filter(attribute -> WorkOrderConstants.WORKORDER_MESH2_ID.equalsIgnoreCase(attribute.getName()))
//					.findAny().orElse(null).getValue());
//
//			instalationDetailWo.setMesh3Id(listOfAttributes.stream()
//					.filter(attribute -> WorkOrderConstants.WORKORDER_MESH3_ID.equalsIgnoreCase(attribute.getName()))
//					.findAny().orElse(null).getValue());
//
//			instalationDetailWo.setMesh4Id(listOfAttributes.stream()
//					.filter(attribute -> WorkOrderConstants.WORKORDER_MESH4_ID.equalsIgnoreCase(attribute.getName()))
//					.findAny().orElse(null).getValue());
//
//			instalationDetailWo.setMesh5Id(listOfAttributes.stream()
//					.filter(attribute -> WorkOrderConstants.WORKORDER_MESH5_ID.equalsIgnoreCase(attribute.getName()))
//					.findAny().orElse(null).getValue());
//
//			instalationDetailWo.setReturnReason(listOfAttributes.stream().filter(
//					attribute -> WorkOrderConstants.WORKORDER_RETURN_REASON.equalsIgnoreCase(attribute.getName()))
//					.findAny().orElse(null).getValue());
//
//			instalationDetailWo.setReturnRemarks(listOfAttributes.stream().filter(
//					attribute -> WorkOrderConstants.WORKORDER_RETURN_REMARKS.equalsIgnoreCase(attribute.getName()))
//					.findAny().orElse(null).getValue());
			InstallatonDetail instalationDetailWo = new InstallatonDetail();
			listOfAttributes.stream().forEach(attributeItem -> {
				switch (attributeItem.getName()) {
					case WorkOrderConstants.WORKORDER_INSTALLER_ARRIVAL_DATE_TIME:
						instalationDetailWo.setInstallerArrivalDate(attributeItem.getValue());
						instalationDetailWo.setInstallerArrived(true);
						break;
					case WorkOrderConstants.WORKORDER_LOCATION:
						instalationDetailWo.setLocation(attributeItem.getValue());
						break;
					case WorkOrderConstants.WORKORDER_STREET_NAME:
						instalationDetailWo.setStreetName(attributeItem.getValue());
						break;
					case WorkOrderConstants.WORKORDER_LONGITUDE:
						instalationDetailWo.setLongitude(attributeItem.getValue());
						break;
					case WorkOrderConstants.WORKORDER_LATITUDE:
						instalationDetailWo.setLatitude(attributeItem.getValue());
						break;
					case WorkOrderConstants.WORKORDER_INSTALLATION_COMPLETE_DATE_TIME:
						instalationDetailWo.setInstallationCompleteDate(attributeItem.getValue());
						instalationDetailWo.setInstallationCompleted(true);
						break;
					case WorkOrderConstants.WORKORDER_WORK_ORDER_COMPLETE_DATE:
						instalationDetailWo.setWorkorderCompleteDate(attributeItem.getValue());
						instalationDetailWo.setWorkOrderCompleted(true);
						break;
					case WorkOrderConstants.WORKORDER_RETURNED_DATE_TIME:
						instalationDetailWo.setReturnedDate(attributeItem.getValue());
						instalationDetailWo.setReturned(true);
						break;
					case WorkOrderConstants.WORKORDER_CABLE_LENGTH:
						instalationDetailWo.setCableLength(attributeItem.getValue());
						break;
					case WorkOrderConstants.WORKORDER_RGW_ID:
						instalationDetailWo.setRgwId(attributeItem.getValue());
						break;
					case WorkOrderConstants.WORKORDER_BTU_ID:
						instalationDetailWo.setBtuId(attributeItem.getValue());
						break;
					case WorkOrderConstants.WORKORDER_MESH1_ID:
						instalationDetailWo.setMesh1Id(attributeItem.getValue());
						break;
					case "WorkOrderConstants.WORKORDER_MESH2_ID":
						instalationDetailWo.setMesh2Id(attributeItem.getValue());
						break;
					case "WorkOrderConstants.WORKORDER_MESH3_ID":
						instalationDetailWo.setMesh2Id(attributeItem.getValue());
						break;
					case "WorkOrderConstants.WORKORDER_MESH4_ID":
						instalationDetailWo.setMesh2Id(attributeItem.getValue());
						break;
					case "WorkOrderConstants.WORKORDER_MESH5_ID":
						instalationDetailWo.setMesh2Id(attributeItem.getValue());
						break;
					case "WorkOrderConstants.WORKORDER_RETURN_REASON":
						instalationDetailWo.setReturnReason(attributeItem.getValue());
						break;
					case "WorkOrderConstants.WORKORDER_RETURN_REMARKS":
						instalationDetailWo.setReturnRemarks(attributeItem.getValue());
						break;
				}
			});
			System.out.println(instalationDetailWo);
			return instalationDetailWo;
		}
		
		return null;
	}
	
	public SubscriberProducts getProductDetailsForOnsiteTrobuleTicket(String subscriberId, String accessToken) throws NotContextException, ServerNotActiveException {
		
		SubscriberProducts productsSubscribedResposne =  new SubscriberProducts();
		List<ProductItem> productItemsFiltered =  new ArrayList<ProductItem>();
		SubscriberProductsResponse responseSubribeProductFromHobs  = subscriberProductService.getSubscriberProductService(subscriberId, accessToken);
		
		
		if(responseSubribeProductFromHobs!=null && responseSubribeProductFromHobs.getStatusList()!=null) {
			
			List<Product> productSubscribed = responseSubribeProductFromHobs.getProducts();
			
			if(productSubscribed.size()>0) {
				
				productSubscribed.stream()
					.filter(productItem -> productItem.getProductType().equalsIgnoreCase("DEVICE"))
					.collect(Collectors.toList())
					.forEach((pItem) -> {
						productActiveStartDate = "";
						productActiveEndDate = "";
						if(pItem.getProductTimePeriod()!=null) {
							productActiveStartDate = pItem.getProductTimePeriod().getStartDateTime().toString();
							productActiveEndDate = pItem.getProductTimePeriod().getEndDateTime().toString();
						}
						
						List<ProductCharacteristicValue> productCharValueList = pItem.getProductCharacteristicValue();
						
						if(productCharValueList!=null && productCharValueList.size() > 0) {
							productCharValueList.stream()
							.filter(prodSpecChar -> prodSpecChar.getProductSpecCharacteristic().getName().contains("RGW"))
							.collect(Collectors.toList())
							.forEach((prodSpecCharValueList) ->{
								
								serialNoFromResponse = "";
								List<ProductSpecCharacteristicValue> prodSpecCharValue = new ArrayList<ProductSpecCharacteristicValue>();
								prodSpecCharValue = prodSpecCharValueList.getProductSpecCharacteristic().getProductSpecCharacteristicValue();
							
								ProductSpecCharacteristicValue specCharactersticValue = prodSpecCharValue.stream()
								.filter(prodSpecValue -> !StringUtils.isBlank(prodSpecValue.getValue()))
								.filter(prodSpecValue -> prodSpecValue.isDefault())
								.findFirst()
								.orElse(null);
								
								serialNoFromResponse = specCharactersticValue.getValue();
								
							});
						}
						
						if(productItemsFiltered!=null && productItemsFiltered.size()>0) {
							productItemsFiltered.add(new ProductItem(pItem.getProductID(),
								pItem.getName(),
								pItem.getProductStatus(),
								pItem.getProductCategory(),
								pItem.getProductType(),
								pItem.getProductSubType(),
								pItem.getServiceType(),
								pItem.getProductFamilyInstanceID(),
								pItem.getAssociatedOfferInstanceID(),
								pItem.getProductSpecificationRefID(),
								pItem.getProductOfferingRefID(),
								productActiveStartDate,
								productActiveEndDate, serialNoFromResponse , "")
								);
						}
						
					});
			
				productsSubscribedResposne.setSubscriberId(subscriberId);
				productsSubscribedResposne.setProductItems(productItemsFiltered);
			}
			
			
		}
		
		
		return productsSubscribedResposne;
		
	}
	
	
	public OwnOrderDetails getOrderDetailsForWorkOrderByOrderId(String orderId, String igwAccessToken) throws NotContextException, ServerNotActiveException {
		
		OwnOrderDetails orderDeatilsResponse = new OwnOrderDetails();
		
		
		OrderListRetrieveResponse orderDataResponseFromIGW = orderDetailsService.getOrderDetailByOrderIdService(igwAccessToken, orderId);
		
		
		if(orderDataResponseFromIGW.getOrderList() !=null && orderDataResponseFromIGW.getOrderList().size()>0) {
			
			OrderList orderListResponse = orderDataResponseFromIGW.getOrderList().stream()
					.filter(orderResponse -> !StringUtils.isNotEmpty(orderResponse.getOrderHeader().getOrderID()))
					.findFirst()
					.orElse(null);
			
			orderDeatilsResponse.setOrderID(orderListResponse.getOrderHeader().getOrderID());
			orderDeatilsResponse.setOrderType(orderListResponse.getOrderHeader().getOrderType());
			orderDeatilsResponse.setOrderType(orderListResponse.getOrderHeader().getOrderStatus());
			orderDeatilsResponse.setOrderProcessingStatus(orderListResponse.getOrderHeader().getOrderProcessingStatus());
			orderDeatilsResponse.setOrderChannel(orderListResponse.getOrderHeader().getOrderChannel());
			orderDeatilsResponse.setReasonCode(orderListResponse.getOrderHeader().getReasonCode());
			orderDeatilsResponse.setCustomerRequestedDate(orderListResponse.getOrderHeader().getCustomerRequestedDate());
			
			CommonInformation commonInformation =  orderListResponse.getCommonInformation();
			if(commonInformation!=null) {
				orderDeatilsResponse.setCustomerAccountID(commonInformation.getCustomerAccount().getCustomerAccountID());
				orderDeatilsResponse.setCustomerId(commonInformation.getCustomer().getCustomerID());
			}
			
			List<OrderLine> listofOrderItems =  orderListResponse.getOrderLines();
			
			OrderLine orderItemFiltered = listofOrderItems.stream()
					.filter(orderItem -> !StringUtils.isNotEmpty(orderItem.getOrderLineID()))
					.findFirst()
					.orElse(null);
			
			OrderProductDetail orderProductDetail =  new OrderProductDetail(); 
			List<OrderProductItem> productItemList = new ArrayList<OrderProductItem>();
			
			orderProductDetail.setOrderLineID(orderItemFiltered.getOrderLineID());
			orderItemFiltered.setOrderLineStatus(orderItemFiltered.getOrderLineStatus());
			Subscriber subscriberDetail = orderItemFiltered.getSubscriberOrderItem().getSubscriber();
			
			if(subscriberDetail!=null && subscriberDetail.getSubscriberProducts().size()>0) {
				
				
				orderProductDetail.setCustomerAccountID(subscriberDetail.getCustomerAccountID());
				orderProductDetail.setCustomerId(subscriberDetail.getCustomerId());
				orderProductDetail.setSubscriberID(subscriberDetail.getSubscriberID());
				
				for (SubscriberProduct subscribeProduct : subscriberDetail.getSubscriberProducts()) {
					OrderProductItem productItem =  new OrderProductItem();
					productItem.setProductID(subscribeProduct.getProductID());
					productItem.setName(subscribeProduct.getName());
					productItem.setProductStatus(subscribeProduct.getProductStatus());
					productItem.setProductCategory(subscribeProduct.getProductCategory());
					productItem.setProductType(subscribeProduct.getProductType());
					productItem.setProductSubType(subscribeProduct.getProductSubType());
					productItem.setPriceOverride(subscribeProduct.getPriceOverride());
					productItem.setProductFamilyInstanceID(subscribeProduct.getProductFamilyInstanceID());
					productItem.setAssociatedOfferInstanceID(subscribeProduct.getAssociatedOfferInstanceID());
					productItem.setProductSpecificationRefID(subscribeProduct.getProductSpecificationRefID());
					productItem.setProductOfferingRefID(subscribeProduct.getProductOfferingRefID());
					
					if(subscribeProduct.getProductTimePeriod()!=null &&
							(!StringUtils.isNotEmpty(subscribeProduct.getProductTimePeriod().getStartDateTime()) && 
									!StringUtils.isNotEmpty(subscribeProduct.getProductTimePeriod().getEndDateTime()))) {
						productItem.setStartDateTime(subscribeProduct.getProductTimePeriod().getStartDateTime());
						productItem.setEndDateTime(subscribeProduct.getProductTimePeriod().getEndDateTime());
					}
		
					productItemList.add(productItem);
				}
				
				orderProductDetail.setProductItem(productItemList);
				
			}
			
			orderDeatilsResponse.setOrderProductDetails(orderProductDetail);
			
		
			if(listofOrderItems!=null && listofOrderItems.size() >0) {
				orderDeatilsResponse.setOrderLines(listofOrderItems);	
			}
		
		}

		return orderDeatilsResponse;
	}
	

}
