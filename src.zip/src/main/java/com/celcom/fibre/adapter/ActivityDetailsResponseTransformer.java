package com.celcom.fibre.adapter;

import java.rmi.server.ServerNotActiveException;
import java.util.List;
import java.util.stream.Collectors;

import javax.naming.NotContextException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.celcom.fibre.config.WorkOrderConstants;
import com.celcom.fibre.model.inbound.activity.InstallationAddress;
import com.celcom.fibre.model.inbound.activity.InstallatonDetail;
import com.celcom.fibre.model.inbound.activity.OwnOrderDetails;
import com.celcom.fibre.model.inbound.activity.RelatedWorkOrderDetails;
import com.celcom.fibre.model.inbound.activity.WrapperAcitivtyResponse;
import com.celcom.fibre.model.inbound.customer.CustomerContact;
import com.celcom.fibre.model.inbound.customer.CustomerDetailsResponse;
import com.celcom.fibre.model.outbound.customerdetail.AddressDTO;
import com.celcom.fibre.model.outbound.customerdetail.ContactMediumDTO;
import com.celcom.fibre.model.outbound.customerdetail.CustomerDTO;
import com.celcom.fibre.model.outbound.customerdetail.IndividualNameDTO;
import com.celcom.fibre.model.outbound.customerdetail.InstallerPortalCustomerRetrieveResponseDTO;
import com.celcom.fibre.model.outbound.customerdetail.PartyDTO;
import com.celcom.fibre.model.outbound.workorder.AttributeList;
import com.celcom.fibre.model.outbound.workorder.BusinessInformation;
import com.celcom.fibre.model.outbound.workorder.GetWorkItemDetailsResponseDTO;
import com.celcom.fibre.model.outbound.workorder.ItemContactInfo;
import com.celcom.fibre.service.GetOrderDetailService;

import io.netty.util.internal.StringUtil;


@Service
public class ActivityDetailsResponseTransformer {
	
	@Autowired
	private ActivityDetailsCommonAdapter commonActivityDetailsAdapter;
	
	
	public WrapperAcitivtyResponse getActivityDetailsResponseTransformer(GetWorkItemDetailsResponseDTO workItemDetailsByItemIdResponse, String igwAccessToken) throws NotContextException, ServerNotActiveException {
		
		String ORDER_ID = "";
		String CUSTOMER_ID = "";
		String SUBSCRIBER_ID = "";

		WrapperAcitivtyResponse wrapperActivityResponseTransformer =  new WrapperAcitivtyResponse();
		wrapperActivityResponseTransformer.setBuId(workItemDetailsByItemIdResponse.getBuID());
		wrapperActivityResponseTransformer.setOpID(workItemDetailsByItemIdResponse.getOpID());

		if (workItemDetailsByItemIdResponse.getItem() != null
				&& workItemDetailsByItemIdResponse.getItem().size() > 0) {
			wrapperActivityResponseTransformer
					.setEscalationLevel(workItemDetailsByItemIdResponse.getItem().get(0).getEscalationLevel());
			wrapperActivityResponseTransformer.setItemID(workItemDetailsByItemIdResponse.getItem().get(0).getItemID());
			wrapperActivityResponseTransformer
					.setItemCatgId(workItemDetailsByItemIdResponse.getItem().get(0).getItemCategoryID());
			wrapperActivityResponseTransformer
					.setItemSubTypeId(workItemDetailsByItemIdResponse.getItem().get(0).getItemSubTypeID());
			wrapperActivityResponseTransformer.setItemTypeID(workItemDetailsByItemIdResponse.getItem().get(0).getItemTypeID());
			wrapperActivityResponseTransformer.setTaskAssignedgroup(
					workItemDetailsByItemIdResponse.getItem().get(0).getOpenedByGroup().getAssignedGroup());
			wrapperActivityResponseTransformer.setAssignedTo(
					workItemDetailsByItemIdResponse.getItem().get(0).getOpenedByGroup().getAssignedUserID());
			wrapperActivityResponseTransformer.setItemStatus(workItemDetailsByItemIdResponse.getItem().get(0).getStatusList()
					.getItemStatus().get(0).getSubStatus());
			wrapperActivityResponseTransformer.setItemSeverity(workItemDetailsByItemIdResponse.getItem().get(0).getSeverity());
			wrapperActivityResponseTransformer.setItempriority(workItemDetailsByItemIdResponse.getItem().get(0).getPriority());

			List<ItemContactInfo> contactInfoList = workItemDetailsByItemIdResponse.getItem().get(0)
					.getItemContactInfo();
			
			if (contactInfoList != null && contactInfoList.size() > 0) {
				// Get the itemContactInfo information - Formating the data
				InstallationAddress addressDetails = commonActivityDetailsAdapter
						.getAddressfromWorkOrderDetail(contactInfoList.get(0));
				wrapperActivityResponseTransformer.setAddressDetails(addressDetails);
			}
			
			BusinessInformation businessInfoDetails = workItemDetailsByItemIdResponse.getItem().get(0)
					.getBusinessInformation();
			if (businessInfoDetails != null) {
				// Getting Order Id and customer Id
				ORDER_ID = !StringUtil.isNullOrEmpty(businessInfoDetails.getOrderID()) ? businessInfoDetails.getOrderID() : null;
				CUSTOMER_ID = !StringUtil.isNullOrEmpty(businessInfoDetails.getCustomerID()) ? businessInfoDetails.getCustomerID() : null;
				SUBSCRIBER_ID = !StringUtil.isNullOrEmpty(businessInfoDetails.getSubscriberID()) ? businessInfoDetails.getSubscriberID() : null;
				
				wrapperActivityResponseTransformer.setOrderId(ORDER_ID);
				wrapperActivityResponseTransformer.setCustomerId(CUSTOMER_ID);
				wrapperActivityResponseTransformer.setSubscriberId(SUBSCRIBER_ID);
				
			}

			// Set Assigned Group
			wrapperActivityResponseTransformer.setAssignedGroup(
					workItemDetailsByItemIdResponse.getItem().get(0).getOpenedByGroup().getAssignedGroup());
		
			AttributeList getListofAttributes = workItemDetailsByItemIdResponse.getItem().get(0).getAttributeList();
			if (getListofAttributes != null) {

				InstallatonDetail installationDetail = commonActivityDetailsAdapter
						.processAdditionalAttributestoFields(getListofAttributes);

				wrapperActivityResponseTransformer.setInstallationDetail(installationDetail);
			}

		}	
		
		if (!StringUtil.isNullOrEmpty(ORDER_ID)) {

			OwnOrderDetails orderDeatilsDetails = new OwnOrderDetails();
			orderDeatilsDetails = commonActivityDetailsAdapter.getOrderDetailsForWorkOrderByOrderId(ORDER_ID, igwAccessToken);
			wrapperActivityResponseTransformer.setOwnOrderDetails(orderDeatilsDetails);
			
			RelatedWorkOrderDetails workOrderDetailsResult = commonActivityDetailsAdapter
					.getReturnedOrderDetailsByOrderId(ORDER_ID, igwAccessToken);

			if (workOrderDetailsResult != null) {
				wrapperActivityResponseTransformer.setRelatedWorkOrderDetails(workOrderDetailsResult);
			}
		}
		
	
		if(wrapperActivityResponseTransformer.getItemSubTypeId().equalsIgnoreCase(WorkOrderConstants.WORKORDER_OST_TYPE) && !StringUtil.isNullOrEmpty(SUBSCRIBER_ID)) {
			
			wrapperActivityResponseTransformer.setProductDetails(commonActivityDetailsAdapter
					.getProductDetailsForOnsiteTrobuleTicket(SUBSCRIBER_ID, igwAccessToken));

		}
		
		return wrapperActivityResponseTransformer;
	}
	
	
	public CustomerDetailsResponse getCustomerDetailResponseTransformer(InstallerPortalCustomerRetrieveResponseDTO customerResponseFromIGW) {
		
		CustomerDetailsResponse customerResponsePortal =  new CustomerDetailsResponse();
		
		if(customerResponseFromIGW!=null) {
			
			CustomerDTO customerInfo = customerResponseFromIGW.getCustomer().stream()
					.filter(customer -> !StringUtil.isNullOrEmpty(customer.getCustomerID()))
					.findFirst()
					.orElse(null);
			
			if(customerInfo!=null) {
				
				customerResponsePortal.setCustomerId(customerInfo.getCustomerID());
				customerResponsePortal.setCustomerStatus(customerInfo.getCustomerStatus());
				customerResponsePortal.setCustomerType(customerInfo.getCustomerType());
				customerResponsePortal.setCustomerSubType(customerInfo.getCustomerSubType());
				customerResponsePortal.setCustomerSegment(customerInfo.getCustomerSegment());
				customerResponsePortal.setCustomerCategory(customerInfo.getCustomerCategory());
				customerResponsePortal.setCustomerEffectiveDate(customerInfo.getCustomerEffectiveDate().toString());
				
				
				PartyDTO partyInfo = customerInfo.getParty();
				
				customerResponsePortal.setCustomerGender(partyInfo.getGender());
				customerResponsePortal.setCustomerDob(partyInfo.getDateOfBirth().toString());
				
				IndividualNameDTO individualData = partyInfo.getIndividualName().stream()
				.filter(party -> !StringUtil.isNullOrEmpty(party.getGivenName()))
				.findFirst()
				.orElse(null);
				
				if(individualData != null) {
					
					customerResponsePortal.setCustomerSalutation(individualData.getFormOfAddress());
					customerResponsePortal.setCustomerFirstName(individualData.getGivenName());
					customerResponsePortal.setCustomerLastName(individualData.getFamilyName());
					
				}
				
				ContactMediumDTO contactMediumInfo = customerInfo.getContactMedium().stream()
					.filter(contactMedium -> !StringUtil.isNullOrEmpty(contactMedium.getContactType()))
					.findFirst()
					.orElse(null);
				
				if(contactMediumInfo!=null) {
				
				customerResponsePortal.setCustomerPrimaryEmail(contactMediumInfo.getPrimaryEmailID());
				customerResponsePortal.setCustomertelephoneNumber(contactMediumInfo.getTelephoneNumber());
				
				AddressDTO contactInfo = contactMediumInfo.getAddress().stream()
				.filter(contact ->  !StringUtil.isNullOrEmpty(contact.getAddressID()))
				.findFirst()
				.orElse(null);
				
					if(contactInfo!=null) {
						CustomerContact contactInfoPortal =  new CustomerContact();
						
						contactInfoPortal.setAddressCategory(contactInfo.getAddressCategory());
						contactInfoPortal.setAddressId(contactInfo.getAddressID());
						contactInfoPortal.setAddressType(contactInfo.getAddressType());
						contactInfoPortal.setUnitNo(contactInfo.getAddressLine1());
						contactInfoPortal.setBuildingName(contactInfo.getAddressLine2());
						contactInfoPortal.setFloorNo(contactInfo.getAddressLine3());
						contactInfoPortal.setSection(contactInfo.getAddressLine4());
						contactInfoPortal.setBuildingType(contactInfo.getAddressLine5());
						contactInfoPortal.setBuildingNo(contactInfo.getAddressLine6());
						contactInfoPortal.setPlotNo(contactInfo.getAddressLine7());
						contactInfoPortal.setTown(contactInfo.getTown());
						contactInfoPortal.setCity(contactInfo.getCity());
						contactInfoPortal.setState(contactInfo.getStateOrProvince());
						contactInfoPortal.setPinCode(contactInfo.getPinCode());
						contactInfoPortal.setCountryCode(contactInfo.getCountryCode());
						
						customerResponsePortal.setContactInfo(contactInfoPortal);
						
						
					}
				
				}
				
			}
		}
		
		
		return customerResponsePortal;
		
	}
	

}
