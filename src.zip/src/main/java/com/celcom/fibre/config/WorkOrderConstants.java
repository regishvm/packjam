package com.celcom.fibre.config;

import org.springframework.stereotype.Service;

@Service
public final class WorkOrderConstants {
	

	private WorkOrderConstants() {
		
	}
	
	public static final String WORKORDER_RETURNED_STATUS = "RESERVED_FOR_SHIPPING";
	
	public static final String WORKORDER_INSTALLER_ARRIVAL_DATE_TIME = "INSTALLER_ARRIVAL_DATE_TIME";
	public static final String WORKORDER_LOCATION = "LOCATION";
	public static final String WORKORDER_STREET_NAME = "STREET_NAME";
	public static final String WORKORDER_LONGITUDE = "LONGITUDE";
	public static final String WORKORDER_LATITUDE = "LATITUDE";
	public static final String WORKORDER_INSTALLATION_COMPLETE_DATE_TIME = "INSTALLATION_COMPLETE_DATE_TIME";
	public static final String WORKORDER_WORK_ORDER_COMPLETE_DATE = "WORK_ORDER_COMPLETE_DATE";
	public static final String WORKORDER_RETURNED_DATE_TIME = "RETURNED_DATE_TIME";
	public static final String WORKORDER_CABLE_LENGTH = "CABLE_LENGTH";
	public static final String WORKORDER_RGW_ID = "RGW_ID";
	public static final String WORKORDER_BTU_ID = "BTU_ID";
	public static final String WORKORDER_MESH1_ID = "TO_BE_UPDATED";
	public static final String WORKORDER_MESH2_ID = "TO_BE_UPDATED";
	public static final String WORKORDER_MESH3_ID = "TO_BE_UPDATED";
	public static final String WORKORDER_MESH4_ID = "TO_BE_UPDATED";
	public static final String WORKORDER_MESH5_ID = "TO_BE_UPDATED";
	
	public static final String WORKORDER_RETURN_REASON = "TO_BE_UPDATED";
	public static final String WORKORDER_RETURN_REMARKS = "TO_BE_UPDATED";
	
	public static final String WORKORDER_OST_TYPE= "On Site Troubleshooting";
	
	public static final String ACTDETAILINPUT_REQUESTTYPE = "DETAILS";
	public static final String ACTDETAILINPUT_INTERACTIONID = "CFMP";
	public static final String ACTDETAILINPUT_DESCRIPTION = "GetWorkItemDetails";
	public static final String ACTDETAILINPUT_SOURCE_APPID = "CFMP";
	public static final String ACTDETAILINPUT_SERVICENAME = "GetWorkItemDetails";
	public static final String ACTDETAILINPUT_CLIENTVERSION ="1.0";
	public static final String ACTDETAILINPUT_LANG = "ENG";
	public static final String ACTDETAILINPUT_CHANNEL = "CSA";
	public static final String ACTDETAILINPUT_OPID = "HOB";
	public static final String ACTDETAILINPUT_BUID = "DEFAULT";
	
	public static final String CUSTDETAILINPUT_SERVICENAME = "getCustomerDetails";
	
	
	public static final String TRACKORDERBY_ORDERID = "ORDERID";
	public static final String TRACKORDERBY_CUSTOMERID = "CUSTOMERID";
	public static final String TRACKORDERBY_SERVICEID = "SERVICEID";
	public static final String TRACKORDERBY_ORDERSTATUS ="ORDERSTATUS";
	
	
	
	
	
	
	
	

}
