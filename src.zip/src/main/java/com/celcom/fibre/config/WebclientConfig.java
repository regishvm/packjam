package com.celcom.fibre.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.TrustManagerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;

import ch.qos.logback.classic.Logger;
import io.netty.channel.ChannelOption;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import reactor.netty.http.client.HttpClient;

@Configuration
public class WebclientConfig {
	
	@Value("${client.ssl.trust-store}")
	private Resource trustStore;
	
	@Value("${client.ssl.trust-store-password}")
	private String trustStorePassword;
	
	@Value("${mem.bufferSize}")
	private int dmsBufferSize;
	
	@Value("${timeout.connectTimeout}")
	private int connectTimeout;

	@Value("${timeout.readTimeout}")
	private int readTimeout;

	@Value("${timeout.writeTimeout}")
	private int writeTimeout;
	
	
	public SslContext getSslContext() {
		try (InputStream trustStoreFile = new FileInputStream(trustStore.getURL().getFile())) {
			final TrustManagerFactory trustManagerFactory = TrustManagerFactory
					.getInstance(TrustManagerFactory.getDefaultAlgorithm());
			final KeyStore trustStore = KeyStore.getInstance("JKS");
			trustStore.load(trustStoreFile, trustStorePassword.toCharArray());
			trustManagerFactory.init(trustStore);
			return SslContextBuilder.forClient().trustManager(trustManagerFactory).build();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return null;
		} catch (java.security.cert.CertificateException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {

			e.printStackTrace();
			return null;
		} catch (KeyStoreException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	@Bean
	public WebClient getWebClient() throws IOException {

		HttpClient httpClient = HttpClient.create().doOnRequest((request, connection)->{
			connection.addHandlerLast(new ReadTimeoutHandler(readTimeout,TimeUnit.MILLISECONDS));
			connection.addHandlerLast(new ReadTimeoutHandler(writeTimeout,TimeUnit.MILLISECONDS));
		});

		return WebClient.create().mutate().defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
				.clientConnector(new ReactorClientHttpConnector(httpClient
						.wiretap(true).secure(sslContextSpec -> sslContextSpec.sslContext(this.getSslContext()))))
				.exchangeStrategies(ExchangeStrategies.builder()
						.codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(dmsBufferSize)).build())
				.build();

	}
}
