package com.celcom.fibre.controller;

import java.net.ConnectException;
import java.rmi.server.ServerNotActiveException;
import javax.naming.NotContextException;

import org.apache.http.impl.execchain.RequestAbortedException;
import org.apache.tomcat.util.http.fileupload.impl.InvalidContentTypeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.celcom.fibre.impl.OrderSearchImpl;
import com.celcom.fibre.model.inbound.activity.OrderCompleteDetails;
import com.celcom.fibre.model.inbound.ordersearch.OrderDetailRequest;
import com.celcom.fibre.model.inbound.ordersearch.OrderSearchRequest;
import com.celcom.fibre.model.inbound.ordersearch.OrderSearchResponse;

import io.netty.util.internal.StringUtil;




@RestController
@RequestMapping("/api")
public class OrderSearchController {
	
	@Autowired
	private OrderSearchImpl orderSearchImpl;
	
	@PostMapping("/trackorder")
	public OrderSearchResponse getactivitydetails(
			@RequestBody OrderSearchRequest orderListRequest,
			@RequestHeader("accessToken") String accessToken) throws ConnectException, NotContextException,
			ServerNotActiveException, RequestAbortedException, InvalidContentTypeException {
		try {
			if (accessToken != null && !accessToken.isEmpty()) {
				if (!StringUtil.isNullOrEmpty(orderListRequest.getSearchType())) {
					return orderSearchImpl.getTrackOrderSearchImpl(orderListRequest, accessToken);
				} else {
					throw new InvalidContentTypeException("Bad request");
				}

			} else {
				throw new RequestAbortedException("forbiddenErrMsg");
			}
		} catch (ServerNotActiveException e) {
			throw new ServerNotActiveException(e.getMessage());
		} catch (NotContextException e) {
			throw new NotContextException(e.getMessage());
		} catch (InvalidContentTypeException e) {
			throw new InvalidContentTypeException(e.getMessage());
		} catch (Exception e) {
			throw new ConnectException("Internal Server error");
		}
	}
	
	@PostMapping("/trackorderdetail")
	public OrderCompleteDetails getOrderDetailsByOrderId(
			@RequestBody OrderDetailRequest orderDetailInput,
			@RequestHeader("accessToken") String accessToken) throws ConnectException, NotContextException,
			ServerNotActiveException, RequestAbortedException, InvalidContentTypeException {
		try {
			if (accessToken != null && !accessToken.isEmpty()) {
				if (!StringUtil.isNullOrEmpty(orderDetailInput.getOrderId())) {
					return orderSearchImpl.getOrderFullDetailImpl(orderDetailInput, accessToken);
				} else {
					throw new InvalidContentTypeException("Bad request");
				}

			} else {
				throw new RequestAbortedException("forbiddenErrMsg");
			}
		} catch (ServerNotActiveException e) {
			throw new ServerNotActiveException(e.getMessage());
		} catch (NotContextException e) {
			throw new NotContextException(e.getMessage());
		} catch (InvalidContentTypeException e) {
			throw new InvalidContentTypeException(e.getMessage());
		} catch (Exception e) {
			throw new ConnectException("Internal Server error");
		}
	}

}
