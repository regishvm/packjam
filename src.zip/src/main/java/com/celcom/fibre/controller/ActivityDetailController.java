package com.celcom.fibre.controller;

import java.net.ConnectException;
import java.rmi.server.ServerNotActiveException;
import javax.naming.NotContextException;

import org.apache.http.impl.execchain.RequestAbortedException;
import org.apache.tomcat.util.http.fileupload.impl.InvalidContentTypeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.celcom.fibre.impl.ActivityDetailServiceImpl;
import com.celcom.fibre.model.inbound.activity.ActivityDetailRequest;
import com.celcom.fibre.model.inbound.activity.WrapperAcitivtyResponse;

import io.netty.util.internal.StringUtil;

@RestController
@RequestMapping("/api")
public class ActivityDetailController {

	@Autowired
	private ActivityDetailServiceImpl activitydeatilIMPL;
//ActivityDetailsRetrieveResponseDTO
	@Value("${Custome_InternalServerERR_MSG}")
	private String Custome_InternalServerERR_MSG;

	@PostMapping("/postActivity")
	public WrapperAcitivtyResponse getactivitydetails(
			@RequestBody ActivityDetailRequest activityDetailsRetrieveRequestmodel,
			@RequestHeader("accessToken") String accessToken) throws ConnectException, NotContextException,
			ServerNotActiveException, RequestAbortedException, InvalidContentTypeException {
		try {
			if (accessToken != null && !accessToken.isEmpty()) {

				if ( !StringUtil.isNullOrEmpty(activityDetailsRetrieveRequestmodel.getActivityId())) {

					return activitydeatilIMPL.getCompleteActivityDetailsImpl(activityDetailsRetrieveRequestmodel, accessToken);
				} else {
					throw new InvalidContentTypeException("Bad request");
				}

			} else {
				throw new RequestAbortedException("forbiddenErrMsg");
			}
		} catch (ServerNotActiveException e) {
			throw new ServerNotActiveException(e.getMessage());
		} catch (NotContextException e) {
			throw new NotContextException(e.getMessage());
		} catch (InvalidContentTypeException e) {
			throw new InvalidContentTypeException(e.getMessage());
		} catch (Exception e) {
			throw new ConnectException("Internal Server error");
		}
	}
}
