package com.celcom.fibre.exception;
import java.net.ConnectException;
import java.rmi.server.ServerNotActiveException;

import javax.management.AttributeNotFoundException;
import javax.naming.NotContextException;

import org.apache.http.impl.execchain.RequestAbortedException;
import org.apache.tomcat.util.http.fileupload.impl.InvalidContentTypeException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;


@ControllerAdvice
public class GlobalExceptionHandler {
	// specific exception
		@ExceptionHandler(InvalidContentTypeException.class)
		public ResponseEntity<?> handelBadRequestException(InvalidContentTypeException exception, WebRequest request){
			ErrorDetails details = new ErrorDetails(exception.getMessage(), request.getDescription(false));
			
			return new ResponseEntity(details, HttpStatus.BAD_REQUEST);
		}
		
		@ExceptionHandler(ServerNotActiveException.class)
		public ResponseEntity<?> handelServerNotActiveException(ServerNotActiveException exception, WebRequest request){
			ErrorDetails details = new ErrorDetails(exception.getMessage(), request.getDescription(false));
			
			return new ResponseEntity(details, HttpStatus.SERVICE_UNAVAILABLE);
		}
		
		@ExceptionHandler(RequestAbortedException.class)
		public ResponseEntity<?> handelInvalidKeyException(RequestAbortedException exception, WebRequest request){
			ErrorDetails details = new ErrorDetails(exception.getMessage(), request.getDescription(false));
			
			return new ResponseEntity(details, HttpStatus.FORBIDDEN);
		}
		
		@ExceptionHandler(NotContextException.class)
		public ResponseEntity<?> handelNotContextException(NotContextException exception, WebRequest request){
			ErrorDetails details = new ErrorDetails(exception.getMessage(), request.getDescription(false));
			
			return new ResponseEntity(details, HttpStatus.NOT_FOUND);
		}
		@ExceptionHandler(ConnectException.class)
		public ResponseEntity<?> handelConnectException(ConnectException exception, WebRequest request){
			ErrorDetails details = new ErrorDetails(exception.getMessage(), request.getDescription(false));
			
			return new ResponseEntity(details, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		// Global exception

}
