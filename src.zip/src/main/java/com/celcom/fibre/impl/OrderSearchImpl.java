package com.celcom.fibre.impl;

import java.rmi.server.ServerNotActiveException;

import javax.naming.NotContextException;

import org.apache.tomcat.util.http.fileupload.impl.InvalidContentTypeException;
import org.springframework.beans.factory.annotation.Autowired;

import com.celcom.fibre.adapter.ActivityDetailsCommonAdapter;
import com.celcom.fibre.adapter.ActivityDetailsRequestTransformer;
import com.celcom.fibre.adapter.ActivityDetailsResponseTransformer;
import com.celcom.fibre.adapter.TrackOrderRequestTransformer;
import com.celcom.fibre.adapter.TrackOrderResponseTransformer;
import com.celcom.fibre.config.WorkOrderConstants;
import com.celcom.fibre.model.inbound.activity.CustomerRequest;
import com.celcom.fibre.model.inbound.activity.OrderCompleteDetails;
import com.celcom.fibre.model.inbound.activity.OwnOrderDetails;
import com.celcom.fibre.model.inbound.customer.CustomerDetailsResponse;
import com.celcom.fibre.model.inbound.ordersearch.OrderDetailRequest;
import com.celcom.fibre.model.inbound.ordersearch.OrderSearchRequest;
import com.celcom.fibre.model.inbound.ordersearch.OrderSearchResponse;
import com.celcom.fibre.model.outbound.customerdetail.InstallerPortalCustomerRetrieveResponseDTO;
import com.celcom.fibre.model.outbound.ordersearch.CustomOrderSearchResponseDTO;
import com.celcom.fibre.service.CustomerDetailService;
import com.celcom.fibre.service.OrderListService;

import io.netty.util.internal.StringUtil;

public class OrderSearchImpl {

	@Autowired
	private OrderListService trackOrderService;
	
	@Autowired
	private CustomerDetailService customerService;
	
	@Autowired
	private TrackOrderRequestTransformer trackRequestTransformer;
	
	@Autowired
	private TrackOrderResponseTransformer trackResponseTransformer;
	
	
	@Autowired
	private ActivityDetailsResponseTransformer activityResponseTransformer;
	
	@Autowired
	private ActivityDetailsRequestTransformer activityRequestTransformer;
	
	@Autowired
	private ActivityDetailsCommonAdapter commonActivityDetailsAdapter;
		
	public OrderSearchResponse getTrackOrderSearchImpl(OrderSearchRequest orderListRequest, String igwAccessToken)
			throws InvalidContentTypeException, ServerNotActiveException, NotContextException {
	
		OrderSearchResponse trackOrderResponseToPortal =  new OrderSearchResponse();
		
		if(!StringUtil.isNullOrEmpty(orderListRequest.getSearchType())) {
			switch(orderListRequest.getSearchType()) {
				case WorkOrderConstants.TRACKORDERBY_ORDERID:     
					getOrderListByOrderIDFromIGW(orderListRequest, igwAccessToken);
					break;
				case WorkOrderConstants.TRACKORDERBY_CUSTOMERID:
					getOrderListByCustomerIDFromIGW(orderListRequest, igwAccessToken);
					break;
				case WorkOrderConstants.TRACKORDERBY_ORDERSTATUS:
					getOrderListByOrderStatusFromIGW(orderListRequest, igwAccessToken);
					break;
				case WorkOrderConstants.TRACKORDERBY_SERVICEID:
					getOrderListByServiceIdFromIGW(orderListRequest, igwAccessToken);
					break;
				default:
					trackOrderResponseToPortal = null;
					break;
			}
		}
		return trackOrderResponseToPortal;
	}
	
	
	
	public OrderSearchResponse getOrderListByOrderIDFromIGW(OrderSearchRequest orderIDInput, String igwAccessToken) throws NotContextException, ServerNotActiveException {
		
			CustomOrderSearchResponseDTO responseFromIGWByOrderId = 
					trackOrderService.getOrderDetailByOrderIdService(
							trackRequestTransformer.orderListByOrderIdRequestTransformer(orderIDInput), 
							igwAccessToken);
			
			return trackResponseTransformer.orderListCommonResponseTransformer(responseFromIGWByOrderId);
	}
	
	public OrderSearchResponse getOrderListByCustomerIDFromIGW(OrderSearchRequest orderIDInput, String igwAccessToken) throws NotContextException, ServerNotActiveException {
		
		CustomOrderSearchResponseDTO responseFromIGWByCustomerId = 
				trackOrderService.getOrderDetailByCustomerIdService(
						trackRequestTransformer.orderListByCustomerIdRequestTransformer(orderIDInput), 
						igwAccessToken);
		
		return trackResponseTransformer.orderListCommonResponseTransformer(responseFromIGWByCustomerId);
	}
	
	public OrderSearchResponse getOrderListByOrderStatusFromIGW(OrderSearchRequest orderIDInput, String igwAccessToken) throws NotContextException, ServerNotActiveException {
		
		CustomOrderSearchResponseDTO responseFromIGWByOrderStatus = 
				trackOrderService.getOrderDetailByOrderStatusService(
						trackRequestTransformer.orderListByStatusRequestTransformer(orderIDInput), 
						igwAccessToken);
		
		return trackResponseTransformer.orderListCommonResponseTransformer(responseFromIGWByOrderStatus);
	}
	
	public OrderSearchResponse getOrderListByServiceIdFromIGW(OrderSearchRequest orderIDInput, String igwAccessToken) throws NotContextException, ServerNotActiveException {
		
		CustomOrderSearchResponseDTO responseFromIGWByServiceId = 
				trackOrderService.getOrderDetailByServiceIDService(
						trackRequestTransformer.orderListByServiceIdRequestTransformer(orderIDInput), 
						igwAccessToken);
		
		return trackResponseTransformer.orderListCommonResponseTransformer(responseFromIGWByServiceId);
	}
	
	
	public OrderCompleteDetails getOrderFullDetailImpl(OrderDetailRequest orderDetailInput, String igwAccessToken)
			throws InvalidContentTypeException, ServerNotActiveException, NotContextException {
	
		OrderCompleteDetails orderFullDetail =  new OrderCompleteDetails();
		if(!StringUtil.isNullOrEmpty(orderDetailInput.getOrderId())) {
			OwnOrderDetails orderDeatilsDetails = new OwnOrderDetails();
			orderDeatilsDetails = commonActivityDetailsAdapter.getOrderDetailsForWorkOrderByOrderId(orderDetailInput.getOrderId(), igwAccessToken);
			orderFullDetail.setOrderDetails(orderDeatilsDetails);
		
			if(!StringUtil.isNullOrEmpty(orderDeatilsDetails.getCustomerId())){
				
				CustomerRequest customerInput = new CustomerRequest(orderDeatilsDetails.getCustomerId(), orderDetailInput.getUserId(), orderDetailInput.getOutletId()); 
				CustomerDetailsResponse customerDetailResponse  =  new CustomerDetailsResponse();
				InstallerPortalCustomerRetrieveResponseDTO customerResponseIGW =  new InstallerPortalCustomerRetrieveResponseDTO();
				customerResponseIGW = customerService.getCustomerInformationService(activityRequestTransformer.setCustomerDetailRequestTransformer(customerInput), igwAccessToken);
				customerDetailResponse = activityResponseTransformer.getCustomerDetailResponseTransformer(customerResponseIGW);
				orderFullDetail.setCustomerDetails(customerDetailResponse);
			}
		
		}
		return orderFullDetail;
	}
	
	

}
