package com.celcom.fibre.impl;

import java.rmi.server.ServerNotActiveException;
import java.util.ArrayList;
import java.util.Arrays;


import javax.naming.NotContextException;

import org.apache.tomcat.util.http.fileupload.impl.InvalidContentTypeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.celcom.fibre.model.outbound.activity.ActivityDetailsRetrieveResponseDTO;
import com.celcom.fibre.model.outbound.customerdetail.InstallerPortalCustomerRetrieveResponseDTO;
import com.celcom.fibre.model.outbound.order.OrderListRetrieveResponse;
import com.celcom.fibre.model.inbound.activity.ActivityDetailRequest;
import com.celcom.fibre.model.inbound.activity.ActivityDetailsRetrieveRequestmodel;
import com.celcom.fibre.model.inbound.activity.CustomerRequest;
import com.celcom.fibre.model.inbound.activity.OwnOrderDetails;
import com.celcom.fibre.model.inbound.activity.WrapperAcitivtyResponse;
import com.celcom.fibre.model.inbound.customer.CustomerDetailsResponse;
import com.celcom.fibre.service.CustomerDetailService;
import com.celcom.fibre.service.GetIdService;
import com.celcom.fibre.service.GetOrderDetailService;

import com.celcom.fibre.service.WorkOrderDetailService;

import io.netty.util.internal.StringUtil;

import com.celcom.fibre.model.outbound.workorder.GetWorkItemDetailsRequestDTO;
import com.celcom.fibre.model.outbound.workorder.GetWorkItemDetailsResponseDTO;
import com.celcom.fibre.adapter.ActivityDetailsRequestTransformer;
import com.celcom.fibre.adapter.ActivityDetailsResponseTransformer;

@Service
public class ActivityDetailServiceImpl {

	@Autowired
	private GetIdService activityIdService;

	@Autowired
	private WorkOrderDetailService workItemByItemIDService;
	
	@Autowired
	private CustomerDetailService customerService;
	
	@Autowired
	private ActivityDetailsResponseTransformer activityResponseTransformer;
	
	@Autowired
	private ActivityDetailsRequestTransformer activityRequestTransformer;

	public WrapperAcitivtyResponse getActivityDetailsImpl(
			ActivityDetailsRetrieveRequestmodel activityDetailsRetrieveRequestmodel, String igwAccessToken)
			throws InvalidContentTypeException, ServerNotActiveException, NotContextException {

		if (activityDetailsRetrieveRequestmodel.getActivityDetailsRetrieveRequest().getOpId() != null
				&& !activityDetailsRetrieveRequestmodel.getActivityDetailsRetrieveRequest().getOpId().isEmpty()) {

			try {

				ActivityDetailsRetrieveResponseDTO details = activityIdService
						.getIdsService(activityDetailsRetrieveRequestmodel, igwAccessToken);

				String orderId = details.getItem().get(0).getBusinessInformation().getOrderID();

				WrapperAcitivtyResponse wrapperActivityResponse = new WrapperAcitivtyResponse();
				wrapperActivityResponse.setBuId(details.getBuId());
				wrapperActivityResponse.setEscalationLevel(details.getItem().get(0).getEscalationLevel());
				wrapperActivityResponse.setOpID(details.getOpID());
				wrapperActivityResponse.setItemID(details.getItem().get(0).getItemID());
				wrapperActivityResponse.setItemCatgId(details.getItem().get(0).getItemCategoryID());
				wrapperActivityResponse.setItemSubTypeId(details.getItem().get(0).getItemSubTypeID());
				wrapperActivityResponse.setItemTypeID(details.getItem().get(0).getItemTypeID());
				wrapperActivityResponse
						.setTaskAssignedgroup(details.getItem().get(0).getOpenedByGroup().getAssignedGroup());
				wrapperActivityResponse.setAssignedTo(details.getItem().get(0).getOpenedByGroup().getAssignedUserID());
				wrapperActivityResponse
						.setItemStatus(details.getItem().get(0).getStatusList().getItemStatus().get(0).getSubStatus());
				wrapperActivityResponse.setItemSeverity(details.getItem().get(0).getSeverity());
				wrapperActivityResponse.setItempriority(details.getItem().get(0).getPriority());

				if (details != null) {
					orderId = details.getItem().get(0).getBusinessInformation().getOrderID();
					// cusomerId=details.getItem().get(0).getBusinessInformation().getCustomerID();

//				order Api

//					OrderListRetrieveResponse orderData = igwAccessToken,
//							orderId);
//					OwnOrderDetails orderDeatilsDetails = new OwnOrderDetails();

//					orderDeatilsDetails.setOrderID(orderData.getOrderList().get(0).getOrderHeader().getOrderID());
//					orderDeatilsDetails.setOrderType(orderData.getOrderList().get(0).getOrderHeader().getOrderType());
//					orderDeatilsDetails.setOrderType(orderData.getOrderList().get(0).getOrderHeader().getOrderStatus());
//					orderDeatilsDetails.setOrderProcessingStatus(
//							orderData.getOrderList().get(0).getOrderHeader().getOrderProcessingStatus());
//					orderDeatilsDetails
//							.setOrderChannel(orderData.getOrderList().get(0).getOrderHeader().getOrderChannel());
//					orderDeatilsDetails.setReasonCode(orderData.getOrderList().get(0).getOrderHeader().getReasonCode());
//					orderDeatilsDetails.setCustomerRequestedDate(
//							orderData.getOrderList().get(0).getOrderHeader().getCustomerRequestedDate());
//	            orderDeatilsDetails.setProductType(orderData.getOrderList().get(0).getOrderLines().get(0).getSubscriberOrderItem().getSubscriber().getSubscriberProducts().get(0).getProductType());
//			    orderDeatilsDetails.setProductSubType(orderData.getOrderList().get(0).getOrderLines().get(0).getSubscriberOrderItem().getSubscriber().getSubscriberProducts().get(0).getProductSubType());
//					orderDeatilsDetails.setOrderLines(orderData.getOrderList().get(0).getOrderLines());

//					wrapperActivityResponse.setOwnOrderDetails(orderDeatilsDetails);

//			    customer Api 

//			    wrapperActivityResponse.setOwnOrderDetails(orderDeatilsDetails);	    
//			    wrapperActivityResponse.setOwnCustomerDetails(ownCustomerDetails);	
//			    CustomerRetrieveRequestNewModel customer = new CustomerRetrieveRequestNewModel();
//     		    InstallerPortalCustomerRetrieveResponseDTO customerretrive = activityIdService.getcustomerservice(igwAccessToken , customer);
//			    OwnCustomerDetails ownCustomerDetails = new OwnCustomerDetails();

//			    ownCustomerDetails.setCustomer(customerretrive.getCustomer());
//			    ownCustomerDetails.setStatusList(customerretrive.getStatusList());

//			    wrapperActivityResponse.setOwnCustomerDetails(ownCustomerDetails);

					// realted work Api
//			     relatedworkorderresponse response =

				}

				return wrapperActivityResponse;

			} catch (NotContextException e) {
				throw new NotContextException(e.getMessage());
			} catch (ServerNotActiveException e) {
				throw new ServerNotActiveException(e.getMessage());
			}
		} else {
			throw new InvalidContentTypeException("Bad request");
		}

	}

	public WrapperAcitivtyResponse getCompleteActivityDetailsImpl(
			ActivityDetailRequest activityDetailsInput, String igwAccessToken)
			throws InvalidContentTypeException, ServerNotActiveException, NotContextException {

		
		try {

			WrapperAcitivtyResponse wrapperActivityResponse = new WrapperAcitivtyResponse();
			GetWorkItemDetailsResponseDTO workItemDetailsByItemIdResponse = workItemByItemIDService
					.getWorkItemDetailsByIdService(activityRequestTransformer.setActivityDetailsRequestTransformer(activityDetailsInput), igwAccessToken);
			
			wrapperActivityResponse = activityResponseTransformer.getActivityDetailsResponseTransformer(workItemDetailsByItemIdResponse, igwAccessToken);
			
			if (!StringUtil.isNullOrEmpty(wrapperActivityResponse.getCustomerId())) {
				
				CustomerRequest customerInput = new CustomerRequest(wrapperActivityResponse.getCustomerId(), activityDetailsInput.getUserId(), activityDetailsInput.getOutletId()); 
				CustomerDetailsResponse customerDetailResponse  =  new CustomerDetailsResponse();
				InstallerPortalCustomerRetrieveResponseDTO customerResponseIGW =  new InstallerPortalCustomerRetrieveResponseDTO();
				customerResponseIGW = customerService.getCustomerInformationService(activityRequestTransformer.setCustomerDetailRequestTransformer(customerInput), igwAccessToken);
				customerDetailResponse = activityResponseTransformer.getCustomerDetailResponseTransformer(customerResponseIGW);
				wrapperActivityResponse.setCustomerDetails(customerDetailResponse);
			}
			
			return wrapperActivityResponse;

		} catch (NotContextException e) {
			throw new NotContextException(e.getMessage());
		} catch (ServerNotActiveException e) {
			throw new ServerNotActiveException(e.getMessage());
		}
	}

}
