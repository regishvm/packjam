package com.celcom.fibre.model.inbound.activity;

public class CustomerRequest {
	
	private String customerId =  null;
	private String userId = null;
	private String outletId = null;
	
	
	public CustomerRequest() {
		
	}
	
	
	public CustomerRequest(String customerId, String userId, String outletId) {
		super();
		this.customerId = customerId;
		this.userId = userId;
		this.outletId = outletId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getOutletId() {
		return outletId;
	}
	public void setOutletId(String outletId) {
		this.outletId = outletId;
	}
	
	

}
