package com.celcom.fibre.model.inbound.customer;

import com.celcom.fibre.model.inbound.activity.IGWAuthResponse;

public class CustomerRetrieveRequestModel extends IGWAuthResponse {
	private CustomerRetrieveRequest customerRetrieveRequest;

	public CustomerRetrieveRequestModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerRetrieveRequestModel(String access_token) {
		super(access_token);
		// TODO Auto-generated constructor stub
	}

	public CustomerRetrieveRequestModel(CustomerRetrieveRequest customerRetrieveRequest) {
		super();
		this.customerRetrieveRequest = customerRetrieveRequest;
	}

	public CustomerRetrieveRequest getCustomerRetrieveRequest() {
		return customerRetrieveRequest;
	}

	public void setCustomerRetrieveRequest(CustomerRetrieveRequest customerRetrieveRequest) {
		this.customerRetrieveRequest = customerRetrieveRequest;
	}

	
	
}
