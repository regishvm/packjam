package com.celcom.fibre.model.inbound.order;

import com.celcom.fibre.model.inbound.activity.IGWAuthResponse;

public class OrderListRetrieveRequest {
	 private String orderID ;
	 private String orderStatus ;
	 private String orderType ;
	public OrderListRetrieveRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OrderListRetrieveRequest(String orderID, String orderStatus, String orderType) {
		super();
		this.orderID = orderID;
		this.orderStatus = orderStatus;
		this.orderType = orderType;
	}
	public String getOrderID() {
		return orderID;
	}
	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	
	
	 
}
