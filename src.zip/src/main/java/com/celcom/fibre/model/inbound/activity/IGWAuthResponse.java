package com.celcom.fibre.model.inbound.activity;

public class IGWAuthResponse {
	private String access_token;
//	private String scope;
//	private String token_type;
//	private String expires_in;

	public IGWAuthResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
public IGWAuthResponse(String access_token) {
	super();
	this.access_token = access_token;
}
public String getAccess_token() {
	return access_token;
}
public void setAccess_token(String access_token) {
	this.access_token = access_token;
}
	
}