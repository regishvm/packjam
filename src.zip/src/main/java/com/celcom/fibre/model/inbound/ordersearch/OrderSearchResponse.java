package com.celcom.fibre.model.inbound.ordersearch;

public class OrderSearchResponse {
	
	  private String status;
	  private String message;
	  private String accountId;
	  private String createdOn;
	  private String customerId;
	  private String dealerCode;
	  private String orderContext;
	  private String orderId;
	  private String orderLineId;
	  private String orderLineStatus;
	  private String orderReceivedDate;
	  private String orderStatus;
	  private String orderType;
	  private String serviceAttributeKey;
	  private String serviceAttributeValue;

	public OrderSearchResponse() {
		
	}
	
	


	public OrderSearchResponse(String status, String message, String accountId, String createdOn, String customerId,
			String dealerCode, String orderContext, String orderId, String orderLineId, String orderLineStatus,
			String orderReceivedDate, String orderStatus, String orderType, String serviceAttributeKey,
			String serviceAttributeValue) {
		super();
		this.status = status;
		this.message = message;
		this.accountId = accountId;
		this.createdOn = createdOn;
		this.customerId = customerId;
		this.dealerCode = dealerCode;
		this.orderContext = orderContext;
		this.orderId = orderId;
		this.orderLineId = orderLineId;
		this.orderLineStatus = orderLineStatus;
		this.orderReceivedDate = orderReceivedDate;
		this.orderStatus = orderStatus;
		this.orderType = orderType;
		this.serviceAttributeKey = serviceAttributeKey;
		this.serviceAttributeValue = serviceAttributeValue;
	}




	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}




	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getDealerCode() {
		return dealerCode;
	}

	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	public String getOrderContext() {
		return orderContext;
	}

	public void setOrderContext(String orderContext) {
		this.orderContext = orderContext;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getOrderLineId() {
		return orderLineId;
	}

	public void setOrderLineId(String orderLineId) {
		this.orderLineId = orderLineId;
	}

	public String getOrderLineStatus() {
		return orderLineStatus;
	}

	public void setOrderLineStatus(String orderLineStatus) {
		this.orderLineStatus = orderLineStatus;
	}

	public String getOrderReceivedDate() {
		return orderReceivedDate;
	}

	public void setOrderReceivedDate(String orderReceivedDate) {
		this.orderReceivedDate = orderReceivedDate;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getServiceAttributeKey() {
		return serviceAttributeKey;
	}

	public void setServiceAttributeKey(String serviceAttributeKey) {
		this.serviceAttributeKey = serviceAttributeKey;
	}

	public String getServiceAttributeValue() {
		return serviceAttributeValue;
	}

	public void setServiceAttributeValue(String serviceAttributeValue) {
		this.serviceAttributeValue = serviceAttributeValue;
	}
	
	
	
}
