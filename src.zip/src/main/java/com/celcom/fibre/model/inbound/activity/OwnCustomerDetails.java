package com.celcom.fibre.model.inbound.activity;

import java.util.List;

import com.celcom.fibre.model.outbound.customer.Services;
import com.celcom.fibre.model.outbound.customerdetail.InstallerPortalCustomerRetrieveResponseDTO;

public class OwnCustomerDetails extends InstallerPortalCustomerRetrieveResponseDTO {

	@Override
	public String toString() {
		return "OwnCustomerDetails [getCustomer()=" + getCustomer() + ", getStatusList()=" + getStatusList()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + ", getClass()=" + getClass()
				+ "]";
	}
//	private String customerIDType = null;
//	private String customerRowId = null;
//	private String country = null;
//	private String customerID = null;
//	private List<Services> services = null;
	
	
	
}

