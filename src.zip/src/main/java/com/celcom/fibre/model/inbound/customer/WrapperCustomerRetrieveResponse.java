package com.celcom.fibre.model.inbound.customer;

import java.util.List;

import com.celcom.fibre.model.outbound.customer.Services;

public class WrapperCustomerRetrieveResponse {
	 private String customerIDType = null;
	 private String customerRowId = null;
	 private String contactSalutation = null;
	 private String contactType = null;
	 private String country = null;
	 private String customerID = null;
	 private String name = null;
	 private String postalCode = null;
	 private String state = null;
	 private List<Services> services = null;
	public WrapperCustomerRetrieveResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	public WrapperCustomerRetrieveResponse(String customerIDType, String customerRowId, String contactSalutation,
			String contactType, String country, String customerID, String name, String postalCode, String state,
			List<Services> services) {
		super();
		this.customerIDType = customerIDType;
		this.customerRowId = customerRowId;
		this.contactSalutation = contactSalutation;
		this.contactType = contactType;
		this.country = country;
		this.customerID = customerID;
		this.name = name;
		this.postalCode = postalCode;
		this.state = state;
		this.services = services;
	}
	public String getCustomerIDType() {
		return customerIDType;
	}
	public void setCustomerIDType(String customerIDType) {
		this.customerIDType = customerIDType;
	}
	public String getCustomerRowId() {
		return customerRowId;
	}
	public void setCustomerRowId(String customerRowId) {
		this.customerRowId = customerRowId;
	}
	public String getContactSalutation() {
		return contactSalutation;
	}
	public void setContactSalutation(String contactSalutation) {
		this.contactSalutation = contactSalutation;
	}
	public String getContactType() {
		return contactType;
	}
	public void setContactType(String contactType) {
		this.contactType = contactType;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCustomerID() {
		return customerID;
	}
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public List<Services> getServices() {
		return services;
	}
	public void setServices(List<Services> services) {
		this.services = services;
	}
	 
	 
}
