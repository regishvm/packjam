package com.celcom.fibre.model.inbound.customer;

public class CustomerContact {
	
	private String addressType;
	private String unitNo;   //addressLine1
	private String buildingName; //addressLine2
	private String floorNo; //addressLine3
	private String section; //addressLine4
	private String buildingType; //addressLine5
	private String buildingNo; //addressLine6
	private String plotNo; //addressLine7
	private String town;
	private String city;
	private String state;
	private String pinCode;
	private String countryCode;
	private String addressId;
	private String addressCategory;
	private String addressQualifier;
	private String customerPrimaryEmail;
	private String customertelephoneNumber;
	
	public CustomerContact() {
		
	}
	
	public CustomerContact(String addressType, String unitNo, String buildingName, String floorNo, String section,
			String buildingType, String buildingNo, String plotNo, String town, String city, String state,
			String pinCode, String countryCode, String addressId, String addressCategory, String addressQualifier,
			String customerPrimaryEmail, String customertelephoneNumber) {
		super();
		this.addressType = addressType;
		this.unitNo = unitNo;
		this.buildingName = buildingName;
		this.floorNo = floorNo;
		this.section = section;
		this.buildingType = buildingType;
		this.buildingNo = buildingNo;
		this.plotNo = plotNo;
		this.town = town;
		this.city = city;
		this.state = state;
		this.pinCode = pinCode;
		this.countryCode = countryCode;
		this.addressId = addressId;
		this.addressCategory = addressCategory;
		this.addressQualifier = addressQualifier;
		this.customerPrimaryEmail = customerPrimaryEmail;
		this.customertelephoneNumber = customertelephoneNumber;
	}
	public String getAddressType() {
		return addressType;
	}
	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}
	public String getUnitNo() {
		return unitNo;
	}
	public void setUnitNo(String unitNo) {
		this.unitNo = unitNo;
	}
	public String getBuildingName() {
		return buildingName;
	}
	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	public String getFloorNo() {
		return floorNo;
	}
	public void setFloorNo(String floorNo) {
		this.floorNo = floorNo;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public String getBuildingType() {
		return buildingType;
	}
	public void setBuildingType(String buildingType) {
		this.buildingType = buildingType;
	}
	public String getBuildingNo() {
		return buildingNo;
	}
	public void setBuildingNo(String buildingNo) {
		this.buildingNo = buildingNo;
	}
	public String getPlotNo() {
		return plotNo;
	}
	public void setPlotNo(String plotNo) {
		this.plotNo = plotNo;
	}
	public String getTown() {
		return town;
	}
	public void setTown(String town) {
		this.town = town;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getAddressId() {
		return addressId;
	}
	public void setAddressId(String addressId) {
		this.addressId = addressId;
	}
	public String getAddressCategory() {
		return addressCategory;
	}
	public void setAddressCategory(String addressCategory) {
		this.addressCategory = addressCategory;
	}
	public String getAddressQualifier() {
		return addressQualifier;
	}
	public void setAddressQualifier(String addressQualifier) {
		this.addressQualifier = addressQualifier;
	}
	public String getCustomerPrimaryEmail() {
		return customerPrimaryEmail;
	}
	public void setCustomerPrimaryEmail(String customerPrimaryEmail) {
		this.customerPrimaryEmail = customerPrimaryEmail;
	}
	public String getCustomertelephoneNumber() {
		return customertelephoneNumber;
	}
	public void setCustomertelephoneNumber(String customertelephoneNumber) {
		this.customertelephoneNumber = customertelephoneNumber;
	}
	
	

}
