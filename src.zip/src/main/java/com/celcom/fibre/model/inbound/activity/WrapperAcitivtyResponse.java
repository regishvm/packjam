package com.celcom.fibre.model.inbound.activity;

import com.celcom.fibre.model.inbound.customer.CustomerDetailsResponse;

public class WrapperAcitivtyResponse {
	
	
	private String buId = null;
	private String opID = null;	
	private String  itemNbr = null;	
	private String itemID = null;	
	private String itemVersion = null;	
	private String itemCatgId = null;	
	private String itemSubTypeId = null;	
	private String itemTypeID = null;	
	private String assignedGroup = null;	
	private String assignedUserID = null;	
	private String assignedTo = null;	
	private String itemStatus = null;	
	private String itemSeverity = null;	
	private String itempriority = null;	
	private String resolutionDate = null;	
	private String createdDate = null;	
	private String escalationLevel = null;	
	private String taskId = null;	
	private String taskAssignedgroup = null;	
	private String elapsedTime = null;	
	private String dueTime = null;
	
	private String orderId = null;
	private String customerId =  null;
	private String subscriberId = null;
	
	private InstallationAddress addressDetails = null;
	
	
	private OwnOrderDetails ownOrderDetails;
	private CustomerDetailsResponse customerDetails;
	private SubscriberProducts productDetails;

	
	private RelatedWorkOrderDetails relatedWorkOrderDetails;
	private InstallatonDetail installationDetail;
	
	public WrapperAcitivtyResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	



	public WrapperAcitivtyResponse(String buId, String opID, String itemNbr, String itemID, String itemVersion,
			String itemCatgId, String itemSubTypeId, String itemTypeID, String assignedGroup, String assignedUserID,
			String assignedTo, String itemStatus, String itemSeverity, String itempriority, String resolutionDate,
			String createdDate, String escalationLevel, String taskId, String taskAssignedgroup, String elapsedTime,
			String dueTime, String orderId, String customerId, String subscriberId, InstallationAddress addressDetails,
			OwnOrderDetails ownOrderDetails, CustomerDetailsResponse customerDetails, SubscriberProducts productDetails,
			RelatedWorkOrderDetails relatedWorkOrderDetails, InstallatonDetail installationDetail) {
		super();
		this.buId = buId;
		this.opID = opID;
		this.itemNbr = itemNbr;
		this.itemID = itemID;
		this.itemVersion = itemVersion;
		this.itemCatgId = itemCatgId;
		this.itemSubTypeId = itemSubTypeId;
		this.itemTypeID = itemTypeID;
		this.assignedGroup = assignedGroup;
		this.assignedUserID = assignedUserID;
		this.assignedTo = assignedTo;
		this.itemStatus = itemStatus;
		this.itemSeverity = itemSeverity;
		this.itempriority = itempriority;
		this.resolutionDate = resolutionDate;
		this.createdDate = createdDate;
		this.escalationLevel = escalationLevel;
		this.taskId = taskId;
		this.taskAssignedgroup = taskAssignedgroup;
		this.elapsedTime = elapsedTime;
		this.dueTime = dueTime;
		this.orderId = orderId;
		this.customerId = customerId;
		this.subscriberId = subscriberId;
		this.addressDetails = addressDetails;
		this.ownOrderDetails = ownOrderDetails;
		this.customerDetails = customerDetails;
		this.productDetails = productDetails;
		this.relatedWorkOrderDetails = relatedWorkOrderDetails;
		this.installationDetail = installationDetail;
	}







	public String getBuId() {
		return buId;
	}

	public void setBuId(String buId) {
		this.buId = buId;
	}

	public String getOpID() {
		return opID;
	}

	public void setOpID(String opID) {
		this.opID = opID;
	}

	public String getItemNbr() {
		return itemNbr;
	}

	public void setItemNbr(String itemNbr) {
		this.itemNbr = itemNbr;
	}

	public String getItemID() {
		return itemID;
	}

	public void setItemID(String itemID) {
		this.itemID = itemID;
	}

	public String getItemVersion() {
		return itemVersion;
	}

	public void setItemVersion(String itemVersion) {
		this.itemVersion = itemVersion;
	}

	public String getItemCatgId() {
		return itemCatgId;
	}

	public void setItemCatgId(String itemCatgId) {
		this.itemCatgId = itemCatgId;
	}

	public String getItemSubTypeId() {
		return itemSubTypeId;
	}

	public void setItemSubTypeId(String itemSubTypeId) {
		this.itemSubTypeId = itemSubTypeId;
	}

	public String getItemTypeID() {
		return itemTypeID;
	}

	public void setItemTypeID(String itemTypeID) {
		this.itemTypeID = itemTypeID;
	}

	public String getAssignedGroup() {
		return assignedGroup;
	}

	public void setAssignedGroup(String assignedGroup) {
		this.assignedGroup = assignedGroup;
	}

	public String getAssignedUserID() {
		return assignedUserID;
	}

	public void setAssignedUserID(String assignedUserID) {
		this.assignedUserID = assignedUserID;
	}

	public String getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public String getItemStatus() {
		return itemStatus;
	}

	public void setItemStatus(String itemStatus) {
		this.itemStatus = itemStatus;
	}

	public String getItemSeverity() {
		return itemSeverity;
	}

	public void setItemSeverity(String itemSeverity) {
		this.itemSeverity = itemSeverity;
	}

	public String getItempriority() {
		return itempriority;
	}

	public void setItempriority(String itempriority) {
		this.itempriority = itempriority;
	}

	public String getResolutionDate() {
		return resolutionDate;
	}

	public void setResolutionDate(String resolutionDate) {
		this.resolutionDate = resolutionDate;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getEscalationLevel() {
		return escalationLevel;
	}

	public void setEscalationLevel(String escalationLevel) {
		this.escalationLevel = escalationLevel;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getTaskAssignedgroup() {
		return taskAssignedgroup;
	}

	public void setTaskAssignedgroup(String taskAssignedgroup) {
		this.taskAssignedgroup = taskAssignedgroup;
	}

	public String getElapsedTime() {
		return elapsedTime;
	}

	public void setElapsedTime(String elapsedTime) {
		this.elapsedTime = elapsedTime;
	}

	public String getDueTime() {
		return dueTime;
	}

	public void setDueTime(String dueTime) {
		this.dueTime = dueTime;
	}

	public OwnOrderDetails getOwnOrderDetails() {
		return ownOrderDetails;
	}

	public void setOwnOrderDetails(OwnOrderDetails ownOrderDetails) {
		this.ownOrderDetails = ownOrderDetails;
	}



	public RelatedWorkOrderDetails getRelatedWorkOrderDetails() {
		return relatedWorkOrderDetails;
	}

	public void setRelatedWorkOrderDetails(RelatedWorkOrderDetails relatedWorkOrderDetails) {
		this.relatedWorkOrderDetails = relatedWorkOrderDetails;
	}

	public InstallationAddress getAddressDetails() {
		return addressDetails;
	}

	public void setAddressDetails(InstallationAddress addressDetails) {
		this.addressDetails = addressDetails;
	}

	public InstallatonDetail getInstallationDetail() {
		return installationDetail;
	}

	public void setInstallationDetail(InstallatonDetail installationDetail) {
		this.installationDetail = installationDetail;
	}
	

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}

	public SubscriberProducts getProductDetails() {
		return productDetails;
	}

	public void setProductDetails(SubscriberProducts productDetails) {
		this.productDetails = productDetails;
	}

	@Override
	public String toString() {
		return "WrapperAcitivtyResponse [buId=" + buId + ", opID=" + opID + ", itemNbr=" + itemNbr + ", itemID="
				+ itemID + ", itemVersion=" + itemVersion + ", itemCatgId=" + itemCatgId + ", itemSubTypeId="
				+ itemSubTypeId + ", itemTypeID=" + itemTypeID + ", assignedGroup=" + assignedGroup
				+ ", assignedUserID=" + assignedUserID + ", assignedTo=" + assignedTo + ", itemStatus=" + itemStatus
				+ ", itemSeverity=" + itemSeverity + ", itempriority=" + itempriority + ", resolutionDate="
				+ resolutionDate + ", createdDate=" + createdDate + ", escalationLevel=" + escalationLevel + ", taskId="
				+ taskId + ", taskAssignedgroup=" + taskAssignedgroup + ", elapsedTime=" + elapsedTime + ", dueTime="
				+ dueTime + ", orderId=" + orderId + ", customerId=" + customerId + ", subscriberId=" + subscriberId
				+ ", addressDetails=" + addressDetails + ", ownOrderDetails=" + ownOrderDetails + ", customerDetails="
				+ customerDetails + ", productDetails=" + productDetails + ", relatedWorkOrderDetails="
				+ relatedWorkOrderDetails + ", installationDetail=" + installationDetail + ", getBuId()=" + getBuId()
				+ ", getOpID()=" + getOpID() + ", getItemNbr()=" + getItemNbr() + ", getItemID()=" + getItemID()
				+ ", getItemVersion()=" + getItemVersion() + ", getItemCatgId()=" + getItemCatgId()
				+ ", getItemSubTypeId()=" + getItemSubTypeId() + ", getItemTypeID()=" + getItemTypeID()
				+ ", getAssignedGroup()=" + getAssignedGroup() + ", getAssignedUserID()=" + getAssignedUserID()
				+ ", getAssignedTo()=" + getAssignedTo() + ", getItemStatus()=" + getItemStatus()
				+ ", getItemSeverity()=" + getItemSeverity() + ", getItempriority()=" + getItempriority()
				+ ", getResolutionDate()=" + getResolutionDate() + ", getCreatedDate()=" + getCreatedDate()
				+ ", getEscalationLevel()=" + getEscalationLevel() + ", getTaskId()=" + getTaskId()
				+ ", getTaskAssignedgroup()=" + getTaskAssignedgroup() + ", getElapsedTime()=" + getElapsedTime()
				+ ", getDueTime()=" + getDueTime() + ", getOwnOrderDetails()=" + getOwnOrderDetails()
				+ ", getRelatedWorkOrderDetails()=" + getRelatedWorkOrderDetails() + ", getAddressDetails()="
				+ getAddressDetails() + ", getInstallationDetail()=" + getInstallationDetail() + ", getOrderId()="
				+ getOrderId() + ", getCustomerId()=" + getCustomerId() + ", getSubscriberId()=" + getSubscriberId()
				+ ", getProductDetails()=" + getProductDetails() + ", getCustomerDetails()=" + getCustomerDetails()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}







	public CustomerDetailsResponse getCustomerDetails() {
		return customerDetails;
	}







	public void setCustomerDetails(CustomerDetailsResponse customerDetails) {
		this.customerDetails = customerDetails;
	}
	
	
}