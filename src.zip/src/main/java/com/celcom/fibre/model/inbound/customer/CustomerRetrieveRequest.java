package com.celcom.fibre.model.inbound.customer;

public class CustomerRetrieveRequest  {
	 private String customerIDType ;
	 private String customerRowId ;
	 private String contactSalutation ;
	 private String contactType ;
	 private String country ;
	 private String customerID ;
	public CustomerRetrieveRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CustomerRetrieveRequest(String customerIDType, String customerRowId, String contactSalutation,
			String contactType, String country, String customerID) {
		super();
		this.customerIDType = customerIDType;
		this.customerRowId = customerRowId;
		this.contactSalutation = contactSalutation;
		this.contactType = contactType;
		this.country = country;
		this.customerID = customerID;
	}
	public String getCustomerIDType() {
		return customerIDType;
	}
	public void setCustomerIDType(String customerIDType) {
		this.customerIDType = customerIDType;
	}
	public String getCustomerRowId() {
		return customerRowId;
	}
	public void setCustomerRowId(String customerRowId) {
		this.customerRowId = customerRowId;
	}
	public String getContactSalutation() {
		return contactSalutation;
	}
	public void setContactSalutation(String contactSalutation) {
		this.contactSalutation = contactSalutation;
	}
	public String getContactType() {
		return contactType;
	}
	public void setContactType(String contactType) {
		this.contactType = contactType;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCustomerID() {
		return customerID;
	}
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}
	
	 
}
