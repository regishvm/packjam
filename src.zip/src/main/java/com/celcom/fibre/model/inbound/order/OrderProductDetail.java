package com.celcom.fibre.model.inbound.order;

import java.util.List;

public class OrderProductDetail {
	private String orderLineID;
	private String orderLineStatus;
	private String customerAccountID;
	private String customerId;
	private String subscriberID;
	private List<OrderProductItem> productItem;
	
	
	public OrderProductDetail() {
		
	}
	
	public OrderProductDetail(String orderLineID, String orderLineStatus, String customerAccountID, String customerId,
			String subscriberID, List<OrderProductItem> productItem) {
		super();
		this.orderLineID = orderLineID;
		this.orderLineStatus = orderLineStatus;
		this.customerAccountID = customerAccountID;
		this.customerId = customerId;
		this.subscriberID = subscriberID;
		this.productItem = productItem;
	}
	
	
	public String getOrderLineID() {
		return orderLineID;
	}
	public void setOrderLineID(String orderLineID) {
		this.orderLineID = orderLineID;
	}
	public String getOrderLineStatus() {
		return orderLineStatus;
	}
	public void setOrderLineStatus(String orderLineStatus) {
		this.orderLineStatus = orderLineStatus;
	}
	public String getCustomerAccountID() {
		return customerAccountID;
	}
	public void setCustomerAccountID(String customerAccountID) {
		this.customerAccountID = customerAccountID;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getSubscriberID() {
		return subscriberID;
	}
	public void setSubscriberID(String subscriberID) {
		this.subscriberID = subscriberID;
	}
	public List<OrderProductItem> getProductItem() {
		return productItem;
	}
	public void setProductItem(List<OrderProductItem> productItem) {
		this.productItem = productItem;
	}
	
	

}
