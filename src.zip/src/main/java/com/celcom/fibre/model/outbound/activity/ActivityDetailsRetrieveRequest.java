package com.celcom.fibre.model.outbound.activity;



public class ActivityDetailsRetrieveRequest  {
	private String action;
	private String userId;
	private String opId;
	private String buId;
	private String itemId;
	
	public ActivityDetailsRetrieveRequest() {
		super();
	}

	public ActivityDetailsRetrieveRequest(String action, String userId, String opId, String buId, String itemId) {
		super();
		this.action = action;
		this.userId = userId;
		this.opId = opId;
		this.buId = buId;
		this.itemId = itemId;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getOpId() {
		return opId;
	}

	public void setOpId(String opId) {
		this.opId = opId;
	}

	public String getBuId() {
		return buId;
	}

	public void setBuId(String buId) {
		this.buId = buId;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	
	

}
