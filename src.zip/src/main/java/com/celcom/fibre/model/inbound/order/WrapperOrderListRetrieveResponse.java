package com.celcom.fibre.model.inbound.order;

import java.util.List;

import com.celcom.fibre.model.outbound.order.OrderList;
import com.celcom.fibre.model.outbound.order.OrderListRetrieveResponse;
import com.celcom.fibre.model.outbound.order.StatusList;

public class WrapperOrderListRetrieveResponse  extends OrderListRetrieveResponse {

	 
}
