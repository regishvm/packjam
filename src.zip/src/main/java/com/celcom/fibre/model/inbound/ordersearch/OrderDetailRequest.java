package com.celcom.fibre.model.inbound.ordersearch;

public class OrderDetailRequest {
	
	private String orderId;
	private String outletId;
	private String userId;
	
	
	
	
	public OrderDetailRequest(String orderId, String outletId, String userId) {
		super();
		this.orderId = orderId;
		this.outletId = outletId;
		this.userId = userId;
	}
	
	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getOutletId() {
		return outletId;
	}
	public void setOutletId(String outletId) {
		this.outletId = outletId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}

}
