package com.celcom.fibre.model.inbound.ordersearch;

public class OrderSearchRequest {
	
	private String searchType;
	private String dealerCode;
	private String startDate;
	private String endDate;
	private String orderContext;
	

	private String orderNumber;
	private String orderStatus;
	private String customerId;

	private String srvcAttrKey;
	private String srvcAttrVal;
	
	public OrderSearchRequest() {
		
	}
	
	
	public OrderSearchRequest(String searchType, String dealerCode, String startDate, String endDate,
			String orderContext, String orderNumber, String orderStatus, String customerId, String srvcAttrKey,
			String srvcAttrVal) {
		super();
		this.searchType = searchType;
		this.dealerCode = dealerCode;
		this.startDate = startDate;
		this.endDate = endDate;
		this.orderContext = orderContext;
		this.orderNumber = orderNumber;
		this.orderStatus = orderStatus;
		this.customerId = customerId;
		this.srvcAttrKey = srvcAttrKey;
		this.srvcAttrVal = srvcAttrVal;
	}
	
	
	public String getSearchType() {
		return searchType;
	}
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	public String getDealerCode() {
		return dealerCode;
	}
	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getOrderContext() {
		return orderContext;
	}
	public void setOrderContext(String orderContext) {
		this.orderContext = orderContext;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getSrvcAttrKey() {
		return srvcAttrKey;
	}
	public void setSrvcAttrKey(String srvcAttrKey) {
		this.srvcAttrKey = srvcAttrKey;
	}
	public String getSrvcAttrVal() {
		return srvcAttrVal;
	}
	public void setSrvcAttrVal(String srvcAttrVal) {
		this.srvcAttrVal = srvcAttrVal;
	}
	
	

}
