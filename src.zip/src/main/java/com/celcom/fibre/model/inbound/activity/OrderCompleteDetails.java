package com.celcom.fibre.model.inbound.activity;

import java.util.List;

import com.celcom.fibre.model.inbound.customer.CustomerDetailsResponse;


public class OrderCompleteDetails{
	
	private OwnOrderDetails orderDetails;
	private CustomerDetailsResponse customerDetails;


	public OrderCompleteDetails() {
		
	}
	
	public OrderCompleteDetails(OwnOrderDetails orderDetails, CustomerDetailsResponse customerDetails) {
		super();
		this.orderDetails = orderDetails;
		this.customerDetails = customerDetails;
	}

	public OwnOrderDetails getOrderDetails() {
		return orderDetails;
	}

	public void setOrderDetails(OwnOrderDetails orderDetails) {
		this.orderDetails = orderDetails;
	}

	public CustomerDetailsResponse getCustomerDetails() {
		return customerDetails;
	}

	public void setCustomerDetails(CustomerDetailsResponse customerDetails) {
		this.customerDetails = customerDetails;
	}
	
	

}
