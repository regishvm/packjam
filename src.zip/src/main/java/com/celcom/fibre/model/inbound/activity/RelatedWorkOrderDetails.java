package com.celcom.fibre.model.inbound.activity;

import java.util.List;

public class RelatedWorkOrderDetails {
	private int count ;
	private List<RelatedWorkOrder> relatedWorkOrder ;
	public RelatedWorkOrderDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public RelatedWorkOrderDetails(int count, List<RelatedWorkOrder> relatedWorkOrder) {
		super();
		this.count = count;
		this.relatedWorkOrder = relatedWorkOrder;
	}



	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public List<RelatedWorkOrder> getRelatedWorkOrder() {
		return relatedWorkOrder;
	}
	public void setRelatedWorkOrder(List<RelatedWorkOrder> relatedWorkOrder) {
		this.relatedWorkOrder = relatedWorkOrder;
	}
	
}
