package com.celcom.fibre.model.inbound.customer;

public class CustomerDetailsResponse {
	
	private String customerId;
	private String customerStatus;
	private String customerType;
	private String customerSubType;
	private String customerSegment;
	private String customerCategory;
	private String customerEffectiveDate;
	
	private String customerSalutation;
	private String customerFirstName;
	private String customerLastName;
	private String customerGender;
	private String customerDob;
	private String customerIdentification;
	private String customerIDType;
	private String customerPrimaryEmail;
	private String customertelephoneNumber;
	
	private CustomerContact contactInfo;
	
	
	public CustomerDetailsResponse() {
		
	}
	

	public CustomerDetailsResponse(String customerId, String customerStatus, String customerType,
			String customerSubType, String customerSegment, String customerCategory, String customerEffectiveDate,
			String customerSalutation, String customerFirstName, String customerLastName, String customerGender,
			String customerDob, String customerIdentification, String customerIDType, String customerPrimaryEmail,
			String customertelephoneNumber, CustomerContact contactInfo) {
		super();
		this.customerId = customerId;
		this.customerStatus = customerStatus;
		this.customerType = customerType;
		this.customerSubType = customerSubType;
		this.customerSegment = customerSegment;
		this.customerCategory = customerCategory;
		this.customerEffectiveDate = customerEffectiveDate;
		this.customerSalutation = customerSalutation;
		this.customerFirstName = customerFirstName;
		this.customerLastName = customerLastName;
		this.customerGender = customerGender;
		this.customerDob = customerDob;
		this.customerIdentification = customerIdentification;
		this.customerIDType = customerIDType;
		this.customerPrimaryEmail = customerPrimaryEmail;
		this.customertelephoneNumber = customertelephoneNumber;
		this.contactInfo = contactInfo;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerStatus() {
		return customerStatus;
	}

	public void setCustomerStatus(String customerStatus) {
		this.customerStatus = customerStatus;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getCustomerSubType() {
		return customerSubType;
	}

	public void setCustomerSubType(String customerSubType) {
		this.customerSubType = customerSubType;
	}

	public String getCustomerSegment() {
		return customerSegment;
	}

	public void setCustomerSegment(String customerSegment) {
		this.customerSegment = customerSegment;
	}

	public String getCustomerCategory() {
		return customerCategory;
	}

	public void setCustomerCategory(String customerCategory) {
		this.customerCategory = customerCategory;
	}

	public String getCustomerEffectiveDate() {
		return customerEffectiveDate;
	}

	public void setCustomerEffectiveDate(String customerEffectiveDate) {
		this.customerEffectiveDate = customerEffectiveDate;
	}

	public String getCustomerSalutation() {
		return customerSalutation;
	}

	public void setCustomerSalutation(String customerSalutation) {
		this.customerSalutation = customerSalutation;
	}

	public String getCustomerFirstName() {
		return customerFirstName;
	}

	public void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}

	public String getCustomerLastName() {
		return customerLastName;
	}

	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}

	public String getCustomerGender() {
		return customerGender;
	}

	public void setCustomerGender(String customerGender) {
		this.customerGender = customerGender;
	}

	public String getCustomerDob() {
		return customerDob;
	}

	public void setCustomerDob(String customerDob) {
		this.customerDob = customerDob;
	}

	public String getCustomerIdentification() {
		return customerIdentification;
	}

	public void setCustomerIdentification(String customerIdentification) {
		this.customerIdentification = customerIdentification;
	}

	public String getCustomerIDType() {
		return customerIDType;
	}

	public void setCustomerIDType(String customerIDType) {
		this.customerIDType = customerIDType;
	}

	public String getCustomerPrimaryEmail() {
		return customerPrimaryEmail;
	}

	public void setCustomerPrimaryEmail(String customerPrimaryEmail) {
		this.customerPrimaryEmail = customerPrimaryEmail;
	}

	public String getCustomertelephoneNumber() {
		return customertelephoneNumber;
	}

	public void setCustomertelephoneNumber(String customertelephoneNumber) {
		this.customertelephoneNumber = customertelephoneNumber;
	}

	public CustomerContact getContactInfo() {
		return contactInfo;
	}

	public void setContactInfo(CustomerContact contactInfo) {
		this.contactInfo = contactInfo;
	}
	
	
	 

}
