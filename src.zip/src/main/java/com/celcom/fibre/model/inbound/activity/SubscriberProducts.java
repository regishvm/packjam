package com.celcom.fibre.model.inbound.activity;

import java.util.List;

public class SubscriberProducts {
	
	private String subscriberId;
	private List<ProductItem> productItems;
	
	
	public SubscriberProducts() {
		
	}
	
	public SubscriberProducts(String subscriberId, List<ProductItem> productItems) {
		super();
		this.subscriberId = subscriberId;
		this.productItems = productItems;
	}
	public String getSubscriberId() {
		return subscriberId;
	}
	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}
	public List<ProductItem> getProductItems() {
		return productItems;
	}
	public void setProductItems(List<ProductItem> productItems) {
		this.productItems = productItems;
	}
	
	
}
