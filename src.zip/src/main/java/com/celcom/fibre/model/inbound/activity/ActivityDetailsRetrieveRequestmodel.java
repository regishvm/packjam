package com.celcom.fibre.model.inbound.activity;

import com.celcom.fibre.model.outbound.activity.ActivityDetailsRetrieveRequest;

public class ActivityDetailsRetrieveRequestmodel  {
	private ActivityDetailsRetrieveRequest activityDetailsRetrieveRequest;

	public ActivityDetailsRetrieveRequestmodel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ActivityDetailsRetrieveRequestmodel(ActivityDetailsRetrieveRequest activityDetailsRetrieveRequest) {
		super();
		this.activityDetailsRetrieveRequest = activityDetailsRetrieveRequest;
	}

	public ActivityDetailsRetrieveRequest getActivityDetailsRetrieveRequest() {
		return activityDetailsRetrieveRequest;
	}

	public void setActivityDetailsRetrieveRequest(ActivityDetailsRetrieveRequest activityDetailsRetrieveRequest) {
		this.activityDetailsRetrieveRequest = activityDetailsRetrieveRequest;
	}

	

}
