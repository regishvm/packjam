package com.celcom.fibre.model.inbound.activity;

public class ActivityDetailRequest {
	
	private String activityId;
	private String requestType;
	private String userId;
	private String outletId;
	
	
	public ActivityDetailRequest(String activityId, String requestType, String userId, String outletId) {
		super();
		this.activityId = activityId;
		this.requestType = requestType;
		this.userId = userId;
		this.outletId = outletId;
	}
	
	
	public String getActivityId() {
		return activityId;
	}
	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getOutletId() {
		return outletId;
	}
	public void setOutletId(String outletId) {
		this.outletId = outletId;
	}

	
	
}
