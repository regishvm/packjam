package com.celcom.fibre.model.inbound.order;

public class OrderProductItem {

	private String productID;					
	private String name;				
	private String productStatus;				
	private String productCategory;				
	private String productType;					
	private String productSubType;				
	private String priceOverride;				
	private String productFamilyInstanceID;		
	private String associatedOfferInstanceID;	
	private String productSpecificationRefID;	
	private String productOfferingRefID;	
	private String productPrice;				
	private String startDateTime;
	private String endDateTime;
	private String serviceSpecRefID;
	
	
	public OrderProductItem() {
		
	}
	public OrderProductItem(String productID, String name, String productStatus, String productCategory, String productType,
			String productSubType, String priceOverride, String productFamilyInstanceID,
			String associatedOfferInstanceID, String productSpecificationRefID, String productOfferingRefID,
			String productPrice, String startDateTime, String endDateTime, String serviceSpecRefID) {
		super();
		this.productID = productID;
		this.name = name;
		this.productStatus = productStatus;
		this.productCategory = productCategory;
		this.productType = productType;
		this.productSubType = productSubType;
		this.priceOverride = priceOverride;
		this.productFamilyInstanceID = productFamilyInstanceID;
		this.associatedOfferInstanceID = associatedOfferInstanceID;
		this.productSpecificationRefID = productSpecificationRefID;
		this.productOfferingRefID = productOfferingRefID;
		this.productPrice = productPrice;
		this.startDateTime = startDateTime;
		this.endDateTime = endDateTime;
		this.serviceSpecRefID = serviceSpecRefID;
	}
	
	
	public String getProductID() {
		return productID;
	}
	public void setProductID(String productID) {
		this.productID = productID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProductStatus() {
		return productStatus;
	}
	public void setProductStatus(String productStatus) {
		this.productStatus = productStatus;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getProductSubType() {
		return productSubType;
	}
	public void setProductSubType(String productSubType) {
		this.productSubType = productSubType;
	}
	public String getPriceOverride() {
		return priceOverride;
	}
	public void setPriceOverride(String priceOverride) {
		this.priceOverride = priceOverride;
	}
	public String getProductFamilyInstanceID() {
		return productFamilyInstanceID;
	}
	public void setProductFamilyInstanceID(String productFamilyInstanceID) {
		this.productFamilyInstanceID = productFamilyInstanceID;
	}
	public String getAssociatedOfferInstanceID() {
		return associatedOfferInstanceID;
	}
	public void setAssociatedOfferInstanceID(String associatedOfferInstanceID) {
		this.associatedOfferInstanceID = associatedOfferInstanceID;
	}
	public String getProductSpecificationRefID() {
		return productSpecificationRefID;
	}
	public void setProductSpecificationRefID(String productSpecificationRefID) {
		this.productSpecificationRefID = productSpecificationRefID;
	}
	public String getProductOfferingRefID() {
		return productOfferingRefID;
	}
	public void setProductOfferingRefID(String productOfferingRefID) {
		this.productOfferingRefID = productOfferingRefID;
	}
	public String getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(String productPrice) {
		this.productPrice = productPrice;
	}
	public String getStartDateTime() {
		return startDateTime;
	}
	public void setStartDateTime(String startDateTime) {
		this.startDateTime = startDateTime;
	}
	public String getEndDateTime() {
		return endDateTime;
	}
	public void setEndDateTime(String endDateTime) {
		this.endDateTime = endDateTime;
	}
	public String getServiceSpecRefID() {
		return serviceSpecRefID;
	}
	public void setServiceSpecRefID(String serviceSpecRefID) {
		this.serviceSpecRefID = serviceSpecRefID;
	}
	
	
	
}
