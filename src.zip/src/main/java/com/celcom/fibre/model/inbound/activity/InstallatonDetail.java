package com.celcom.fibre.model.inbound.activity;

public class InstallatonDetail {
	
	private String installerArrivalDate;
	private String location;
	private String streetName;
	private String longitude;
	private String latitude;
	private String installationCompleteDate;
	private String workorderCompleteDate;
	private String returnedDate;
	private String cableLength;
	private String rgwId;
	private String btuId;
	private String mesh1Id;
	private String mesh2Id;
	private String mesh3Id;
	private String mesh4Id;
	private String mesh5Id;
	private String returnReason;
	private String returnRemarks;
	
	private Boolean installerArrived;
	private Boolean installationCompleted;
	private Boolean workOrderCompleted;
	private Boolean returned;
	
	
	public InstallatonDetail() {
		
	}
	
	
	
	
	public InstallatonDetail(String installerArrivalDate, String location, String streetName, String longitude,
			String latitude, String installationCompleteDate, String workorderCompleteDate, String returnedDate,
			String cableLength, String rgwId, String btuId, String mesh1Id, String mesh2Id, String mesh3Id,
			String mesh4Id, String mesh5Id, String returnReason, String returnRemarks, Boolean installerArrived,
			Boolean installationCompleted, Boolean workOrderCompleted, Boolean returned) {
		super();
		this.installerArrivalDate = installerArrivalDate;
		this.location = location;
		this.streetName = streetName;
		this.longitude = longitude;
		this.latitude = latitude;
		this.installationCompleteDate = installationCompleteDate;
		this.workorderCompleteDate = workorderCompleteDate;
		this.returnedDate = returnedDate;
		this.cableLength = cableLength;
		this.rgwId = rgwId;
		this.btuId = btuId;
		this.mesh1Id = mesh1Id;
		this.mesh2Id = mesh2Id;
		this.mesh3Id = mesh3Id;
		this.mesh4Id = mesh4Id;
		this.mesh5Id = mesh5Id;
		this.returnReason = returnReason;
		this.returnRemarks = returnRemarks;
		this.installerArrived = installerArrived;
		this.installationCompleted = installationCompleted;
		this.workOrderCompleted = workOrderCompleted;
		this.returned = returned;
	}
	
	
	
	public String getInstallerArrivalDate() {
		return installerArrivalDate;
	}
	public void setInstallerArrivalDate(String installerArrivalDate) {
		this.installerArrivalDate = installerArrivalDate;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getInstallationCompleteDate() {
		return installationCompleteDate;
	}
	public void setInstallationCompleteDate(String installationCompleteDate) {
		this.installationCompleteDate = installationCompleteDate;
	}
	public String getWorkorderCompleteDate() {
		return workorderCompleteDate;
	}
	public void setWorkorderCompleteDate(String workorderCompleteDate) {
		this.workorderCompleteDate = workorderCompleteDate;
	}
	public String getReturnedDate() {
		return returnedDate;
	}
	public void setReturnedDate(String returnedDate) {
		this.returnedDate = returnedDate;
	}
	public String getCableLength() {
		return cableLength;
	}
	public void setCableLength(String cableLength) {
		this.cableLength = cableLength;
	}
	public String getRgwId() {
		return rgwId;
	}
	public void setRgwId(String rgwId) {
		this.rgwId = rgwId;
	}
	public String getBtuId() {
		return btuId;
	}
	public void setBtuId(String btuId) {
		this.btuId = btuId;
	}
	public String getMesh1Id() {
		return mesh1Id;
	}
	public void setMesh1Id(String mesh1Id) {
		this.mesh1Id = mesh1Id;
	}
	public String getMesh2Id() {
		return mesh2Id;
	}
	public void setMesh2Id(String mesh2Id) {
		this.mesh2Id = mesh2Id;
	}
	public String getMesh3Id() {
		return mesh3Id;
	}
	public void setMesh3Id(String mesh3Id) {
		this.mesh3Id = mesh3Id;
	}
	public String getMesh4Id() {
		return mesh4Id;
	}
	public void setMesh4Id(String mesh4Id) {
		this.mesh4Id = mesh4Id;
	}
	public String getMesh5Id() {
		return mesh5Id;
	}
	public void setMesh5Id(String mesh5Id) {
		this.mesh5Id = mesh5Id;
	}
	public String getReturnReason() {
		return returnReason;
	}
	public void setReturnReason(String returnReason) {
		this.returnReason = returnReason;
	}
	public String getReturnRemarks() {
		return returnRemarks;
	}
	public void setReturnRemarks(String returnRemarks) {
		this.returnRemarks = returnRemarks;
	}
	public Boolean getInstallerArrived() {
		return installerArrived;
	}
	public void setInstallerArrived(Boolean installerArrived) {
		this.installerArrived = installerArrived;
	}
	public Boolean getInstallationCompleted() {
		return installationCompleted;
	}
	public void setInstallationCompleted(Boolean installationCompleted) {
		this.installationCompleted = installationCompleted;
	}
	public Boolean getWorkOrderCompleted() {
		return workOrderCompleted;
	}
	public void setWorkOrderCompleted(Boolean workOrderCompleted) {
		this.workOrderCompleted = workOrderCompleted;
	}
	public Boolean getReturned() {
		return returned;
	}
	public void setReturned(Boolean returned) {
		this.returned = returned;
	}




	@Override
	public String toString() {
		return "InstallatonDetail [installerArrivalDate=" + installerArrivalDate + ", location=" + location
				+ ", streetName=" + streetName + ", longitude=" + longitude + ", latitude=" + latitude
				+ ", installationCompleteDate=" + installationCompleteDate + ", workorderCompleteDate="
				+ workorderCompleteDate + ", returnedDate=" + returnedDate + ", cableLength=" + cableLength + ", rgwId="
				+ rgwId + ", btuId=" + btuId + ", mesh1Id=" + mesh1Id + ", mesh2Id=" + mesh2Id + ", mesh3Id=" + mesh3Id
				+ ", mesh4Id=" + mesh4Id + ", mesh5Id=" + mesh5Id + ", returnReason=" + returnReason
				+ ", returnRemarks=" + returnRemarks + ", installerArrived=" + installerArrived
				+ ", installationCompleted=" + installationCompleted + ", workOrderCompleted=" + workOrderCompleted
				+ ", returned=" + returned + "]";
	}
	

}
