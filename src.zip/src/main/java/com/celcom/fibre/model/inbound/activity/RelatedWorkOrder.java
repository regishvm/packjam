package com.celcom.fibre.model.inbound.activity;

public class RelatedWorkOrder {
	private String activityId;
	private String status;
	private String activityType;	
	private String openDate;
	private String targetResolutionDate;
	private String plannedResolutionDate;
	
	public RelatedWorkOrder(String activityId, String status, String activityType, String openDate,
			String targetResolutionDate, String plannedResolutionDate) {
		super();
		this.activityId = activityId;
		this.status = status;
		this.activityType = activityType;
		this.openDate = openDate;
		this.targetResolutionDate = targetResolutionDate;
		this.plannedResolutionDate = plannedResolutionDate;
	}
	
	
	public String getActivityId() {
		return activityId;
	}
	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getActivityType() {
		return activityType;
	}
	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}
	public String getOpenDate() {
		return openDate;
	}
	public void setOpenDate(String openDate) {
		this.openDate = openDate;
	}
	public String getTargetResolutionDate() {
		return targetResolutionDate;
	}
	public void setTargetResolutionDate(String targetResolutionDate) {
		this.targetResolutionDate = targetResolutionDate;
	}
	public String getPlannedResolutionDate() {
		return plannedResolutionDate;
	}
	public void setPlannedResolutionDate(String plannedResolutionDate) {
		this.plannedResolutionDate = plannedResolutionDate;
	}
	
}
