package com.celcom.fibre.model.inbound.activity;

import java.util.List;

import com.celcom.fibre.model.inbound.order.OrderProductDetail;
import com.celcom.fibre.model.outbound.order.OrderLine;

public class OwnOrderDetails {
	private String orderID;
	private String orderType;
	private String orderStatus;
	private String orderProcessingStatus;
	private String orderChannel;
	private String reasonCode;
	private String customerRequestedDate;
	private String orderCompletionDate;
	private String customerAccountID;
	private String customerId;
	private String subscriberID;
	private String productID;
	private String name;
	private String productCategory;
	private String productType;
	private String productSubType;
	
	private OrderProductDetail orderProductDetails;
	
	private List<OrderLine> orderLines;

	public OwnOrderDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	



	public OwnOrderDetails(String orderID, String orderType, String orderStatus, String orderProcessingStatus,
			String orderChannel, String reasonCode, String customerRequestedDate, String orderCompletionDate,
			String customerAccountID, String customerId, String subscriberID, String productID, String name,
			String productCategory, String productType, String productSubType, OrderProductDetail orderProductDetails,
			List<OrderLine> orderLines) {
		super();
		this.orderID = orderID;
		this.orderType = orderType;
		this.orderStatus = orderStatus;
		this.orderProcessingStatus = orderProcessingStatus;
		this.orderChannel = orderChannel;
		this.reasonCode = reasonCode;
		this.customerRequestedDate = customerRequestedDate;
		this.orderCompletionDate = orderCompletionDate;
		this.customerAccountID = customerAccountID;
		this.customerId = customerId;
		this.subscriberID = subscriberID;
		this.productID = productID;
		this.name = name;
		this.productCategory = productCategory;
		this.productType = productType;
		this.productSubType = productSubType;
		this.orderProductDetails = orderProductDetails;
		this.orderLines = orderLines;
	}







	public String getOrderID() {
		return orderID;
	}

	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getOrderProcessingStatus() {
		return orderProcessingStatus;
	}

	public void setOrderProcessingStatus(String orderProcessingStatus) {
		this.orderProcessingStatus = orderProcessingStatus;
	}

	public String getOrderChannel() {
		return orderChannel;
	}

	public void setOrderChannel(String orderChannel) {
		this.orderChannel = orderChannel;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getCustomerRequestedDate() {
		return customerRequestedDate;
	}

	public void setCustomerRequestedDate(String customerRequestedDate) {
		this.customerRequestedDate = customerRequestedDate;
	}

	public String getOrderCompletionDate() {
		return orderCompletionDate;
	}

	public void setOrderCompletionDate(String orderCompletionDate) {
		this.orderCompletionDate = orderCompletionDate;
	}

	public String getCustomerAccountID() {
		return customerAccountID;
	}

	public void setCustomerAccountID(String customerAccountID) {
		this.customerAccountID = customerAccountID;
	}

	public String getSubscriberID() {
		return subscriberID;
	}

	public void setSubscriberID(String subscriberID) {
		this.subscriberID = subscriberID;
	}

	public String getProductID() {
		return productID;
	}

	public void setProductID(String productID) {
		this.productID = productID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getProductSubType() {
		return productSubType;
	}

	public void setProductSubType(String productSubType) {
		this.productSubType = productSubType;
	}

	public List<OrderLine> getOrderLines() {
		return orderLines;
	}

	public void setOrderLines(List<OrderLine> orderLines) {
		this.orderLines = orderLines;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}



	public OrderProductDetail getOrderProductDetails() {
		return orderProductDetails;
	}



	public void setOrderProductDetails(OrderProductDetail orderProductDetails) {
		this.orderProductDetails = orderProductDetails;
	}
	


}
