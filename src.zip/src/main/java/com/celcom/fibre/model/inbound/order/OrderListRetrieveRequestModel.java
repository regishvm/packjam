package com.celcom.fibre.model.inbound.order;

import com.celcom.fibre.model.inbound.activity.IGWAuthResponse;

public class OrderListRetrieveRequestModel extends IGWAuthResponse {
	private OrderListRetrieveRequest orderListRetrieveRequest;

	public OrderListRetrieveRequestModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderListRetrieveRequestModel(String access_token) {
		super(access_token);
		// TODO Auto-generated constructor stub
	}

	public OrderListRetrieveRequestModel(OrderListRetrieveRequest orderListRetrieveRequest) {
		super();
		this.orderListRetrieveRequest = orderListRetrieveRequest;
	}

	public OrderListRetrieveRequest getOrderListRetrieveRequest() {
		return orderListRetrieveRequest;
	}

	public void setOrderListRetrieveRequest(OrderListRetrieveRequest orderListRetrieveRequest) {
		this.orderListRetrieveRequest = orderListRetrieveRequest;
	}


	
}
