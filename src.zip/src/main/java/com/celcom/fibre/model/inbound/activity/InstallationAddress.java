package com.celcom.fibre.model.inbound.activity;

public class InstallationAddress {
	
	private String unitNumber;
	private String buildingName;
	private String stretName;
	private String floorNumber;
	private String addressType;
	private String addressCity;
	private String countryCode;
	private String pinCode;
	
	private String primaryEmail;
	private String contactNumber;
	private String dayContactNumber;

	public InstallationAddress() {
		super();
	}


	public InstallationAddress(String unitNumber, String buildingName, String stretName, String floorNumber,
			String addressType, String addressCity, String countryCode, String pinCode, String primaryEmail,
			String contactNumber, String dayContactNumber) {
		super();
		this.unitNumber = unitNumber;
		this.buildingName = buildingName;
		this.stretName = stretName;
		this.floorNumber = floorNumber;
		this.addressType = addressType;
		this.addressCity = addressCity;
		this.countryCode = countryCode;
		this.pinCode = pinCode;
		this.primaryEmail = primaryEmail;
		this.contactNumber = contactNumber;
		this.dayContactNumber = dayContactNumber;
	}
	
	
	public String getUnitNumber() {
		return unitNumber;
	}
	public void setUnitNumber(String unitNumber) {
		this.unitNumber = unitNumber;
	}
	public String getBuildingName() {
		return buildingName;
	}
	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	public String getStretName() {
		return stretName;
	}
	public void setStretName(String stretName) {
		this.stretName = stretName;
	}
	public String getFloorNumber() {
		return floorNumber;
	}
	public void setFloorNumber(String floorNumber) {
		this.floorNumber = floorNumber;
	}
	public String getAddressType() {
		return addressType;
	}
	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}
	public String getAddressCity() {
		return addressCity;
	}
	public void setAddressCity(String addressCity) {
		this.addressCity = addressCity;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getPrimaryEmail() {
		return primaryEmail;
	}
	public void setPrimaryEmail(String primaryEmail) {
		this.primaryEmail = primaryEmail;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getDayContactNumber() {
		return dayContactNumber;
	}
	public void setDayContactNumber(String dayContactNumber) {
		this.dayContactNumber = dayContactNumber;
	}

}
