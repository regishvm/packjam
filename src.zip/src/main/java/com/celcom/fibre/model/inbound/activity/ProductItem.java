package com.celcom.fibre.model.inbound.activity;

public class ProductItem {
	
	private String productID;
	private String name;
	private String productStatus;
	private String productCategory;
	private String productType;
	private String productSubType;
	private String serviceType;
	private String productFamilyInstanceID;
	private String associatedOfferInstanceID;
	private String productSpecificationRefID;
	private String productOfferingRefID;
	private String startDateTime;
	private String endDateTime;
	private String serialNo;
	private String previousSerialNo;
	
	
	
	
	public ProductItem(String productID, String name, String productStatus, String productCategory, String productType,
			String productSubType, String serviceType, String productFamilyInstanceID, String associatedOfferInstanceID,
			String productSpecificationRefID, String productOfferingRefID, String startDateTime, String endDateTime,
			String serialNo, String previousSerialNo) {
		super();
		this.productID = productID;
		this.name = name;
		this.productStatus = productStatus;
		this.productCategory = productCategory;
		this.productType = productType;
		this.productSubType = productSubType;
		this.serviceType = serviceType;
		this.productFamilyInstanceID = productFamilyInstanceID;
		this.associatedOfferInstanceID = associatedOfferInstanceID;
		this.productSpecificationRefID = productSpecificationRefID;
		this.productOfferingRefID = productOfferingRefID;
		this.startDateTime = startDateTime;
		this.endDateTime = endDateTime;
		this.serialNo = serialNo;
		this.previousSerialNo = previousSerialNo;
	}
	
	
	public String getProductID() {
		return productID;
	}
	public void setProductID(String productID) {
		this.productID = productID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProductStatus() {
		return productStatus;
	}
	public void setProductStatus(String productStatus) {
		this.productStatus = productStatus;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getProductSubType() {
		return productSubType;
	}
	public void setProductSubType(String productSubType) {
		this.productSubType = productSubType;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getProductFamilyInstanceID() {
		return productFamilyInstanceID;
	}
	public void setProductFamilyInstanceID(String productFamilyInstanceID) {
		this.productFamilyInstanceID = productFamilyInstanceID;
	}
	public String getAssociatedOfferInstanceID() {
		return associatedOfferInstanceID;
	}
	public void setAssociatedOfferInstanceID(String associatedOfferInstanceID) {
		this.associatedOfferInstanceID = associatedOfferInstanceID;
	}
	public String getProductSpecificationRefID() {
		return productSpecificationRefID;
	}
	public void setProductSpecificationRefID(String productSpecificationRefID) {
		this.productSpecificationRefID = productSpecificationRefID;
	}
	public String getProductOfferingRefID() {
		return productOfferingRefID;
	}
	public void setProductOfferingRefID(String productOfferingRefID) {
		this.productOfferingRefID = productOfferingRefID;
	}
	public String getStartDateTime() {
		return startDateTime;
	}
	public void setStartDateTime(String startDateTime) {
		this.startDateTime = startDateTime;
	}
	public String getEndDateTime() {
		return endDateTime;
	}
	public void setEndDateTime(String endDateTime) {
		this.endDateTime = endDateTime;
	}
	public String getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	public String getPreviousSerialNo() {
		return previousSerialNo;
	}
	public void setPreviousSerialNo(String previousSerialNo) {
		this.previousSerialNo = previousSerialNo;
	}

	
	
}
