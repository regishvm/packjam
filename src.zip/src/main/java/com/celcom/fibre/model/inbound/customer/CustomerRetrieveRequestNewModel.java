package com.celcom.fibre.model.inbound.customer;

import com.celcom.fibre.model.inbound.activity.IGWAuthResponse;
import com.celcom.fibre.model.outbound.customerdetail.InstallerPortalCustomerRetrieveRequestDTO;

public class CustomerRetrieveRequestNewModel extends IGWAuthResponse {

	private InstallerPortalCustomerRetrieveRequestDTO installerPortalCustomerRetrieveRequestDTO;

	public CustomerRetrieveRequestNewModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerRetrieveRequestNewModel(String access_token) {
		super(access_token);
		// TODO Auto-generated constructor stub
	}

	public CustomerRetrieveRequestNewModel(
			InstallerPortalCustomerRetrieveRequestDTO installerPortalCustomerRetrieveRequestDTO) {
		super();
		this.installerPortalCustomerRetrieveRequestDTO = installerPortalCustomerRetrieveRequestDTO;
	}

	public InstallerPortalCustomerRetrieveRequestDTO getInstallerPortalCustomerRetrieveRequestDTO() {
		return installerPortalCustomerRetrieveRequestDTO;
	}

	public void setInstallerPortalCustomerRetrieveRequestDTO(
			InstallerPortalCustomerRetrieveRequestDTO installerPortalCustomerRetrieveRequestDTO) {
		this.installerPortalCustomerRetrieveRequestDTO = installerPortalCustomerRetrieveRequestDTO;
	}
	
}
