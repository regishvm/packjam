package javassist;

public class NotFoundException {

}
