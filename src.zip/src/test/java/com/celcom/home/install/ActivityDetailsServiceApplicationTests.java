package com.celcom.home.install;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActivityDetailsServiceApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
